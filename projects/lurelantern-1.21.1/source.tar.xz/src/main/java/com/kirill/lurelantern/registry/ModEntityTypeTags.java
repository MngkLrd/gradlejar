package com.kirill.lurelantern.registry;

import com.kirill.lurelantern.LureLanternMod;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.tags.TagKey;
import net.minecraft.world.entity.EntityType;

public final class ModEntityTypeTags {
    public static final TagKey<EntityType<?>> FORCE_LURABLE = create("force_lurable");
    public static final TagKey<EntityType<?>> LURE_IMMUNE = create("lure_immune");

    private ModEntityTypeTags() {
    }

    private static TagKey<EntityType<?>> create(String name) {
        return TagKey.create(Registries.ENTITY_TYPE, ResourceLocation.fromNamespaceAndPath(LureLanternMod.MOD_ID, name));
    }
}

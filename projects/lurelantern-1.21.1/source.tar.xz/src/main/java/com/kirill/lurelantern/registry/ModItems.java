package com.kirill.lurelantern.registry;

import com.kirill.lurelantern.LureLanternMod;
import net.minecraft.core.registries.Registries;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.Item;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.registries.DeferredRegister;

public final class ModItems {
    public static final DeferredRegister<Item> ITEMS = DeferredRegister.create(Registries.ITEM, LureLanternMod.MOD_ID);

    public static final DeferredHolder<Item, BlockItem> LURE_LANTERN = ITEMS.register(
            "lure_lantern",
            () -> new BlockItem(ModBlocks.LURE_LANTERN.get(), new Item.Properties())
    );

    private ModItems() {
    }

    public static void register(IEventBus eventBus) {
        ITEMS.register(eventBus);
    }
}

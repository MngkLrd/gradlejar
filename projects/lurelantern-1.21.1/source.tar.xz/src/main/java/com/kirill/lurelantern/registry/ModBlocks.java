package com.kirill.lurelantern.registry;

import com.kirill.lurelantern.LureLanternMod;
import com.kirill.lurelantern.block.LureLanternBlock;
import net.minecraft.core.registries.Registries;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.registries.DeferredRegister;

public final class ModBlocks {
    public static final DeferredRegister<Block> BLOCKS = DeferredRegister.create(Registries.BLOCK, LureLanternMod.MOD_ID);

    public static final DeferredHolder<Block, LureLanternBlock> LURE_LANTERN = BLOCKS.register(
            "lure_lantern",
            () -> new LureLanternBlock(
                    BlockBehaviour.Properties.ofFullCopy(Blocks.LANTERN)
                            .lightLevel(state -> state.getValue(LureLanternBlock.ACTIVE) ? 15 : 12)
                            .noOcclusion()
            )
    );

    private ModBlocks() {
    }

    public static void register(IEventBus eventBus) {
        BLOCKS.register(eventBus);
    }
}

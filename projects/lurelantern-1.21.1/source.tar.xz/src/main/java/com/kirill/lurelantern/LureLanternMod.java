package com.kirill.lurelantern;

import com.kirill.lurelantern.registry.ModBlockEntities;
import com.kirill.lurelantern.registry.ModBlocks;
import com.kirill.lurelantern.registry.ModItems;
import com.mojang.logging.LogUtils;
import net.minecraft.world.item.CreativeModeTabs;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.fml.common.Mod;
import net.neoforged.neoforge.event.BuildCreativeModeTabContentsEvent;
import org.slf4j.Logger;

@Mod(LureLanternMod.MOD_ID)
public final class LureLanternMod {
    public static final String MOD_ID = "lurelantern";
    public static final Logger LOGGER = LogUtils.getLogger();

    public LureLanternMod(IEventBus modEventBus) {
        ModBlocks.register(modEventBus);
        ModItems.register(modEventBus);
        ModBlockEntities.register(modEventBus);

        modEventBus.addListener(this::addCreativeTabItems);
    }

    private void addCreativeTabItems(BuildCreativeModeTabContentsEvent event) {
        if (event.getTabKey() == CreativeModeTabs.FUNCTIONAL_BLOCKS) {
            event.accept(ModItems.LURE_LANTERN.get());
        }
    }
}

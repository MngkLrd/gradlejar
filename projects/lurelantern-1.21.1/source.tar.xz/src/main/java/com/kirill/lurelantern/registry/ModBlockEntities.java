package com.kirill.lurelantern.registry;

import com.kirill.lurelantern.LureLanternMod;
import com.kirill.lurelantern.blockentity.LureLanternBlockEntity;
import net.minecraft.core.registries.Registries;
import net.minecraft.world.level.block.entity.BlockEntityType;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.registries.DeferredRegister;

public final class ModBlockEntities {
    public static final DeferredRegister<BlockEntityType<?>> BLOCK_ENTITY_TYPES = DeferredRegister.create(Registries.BLOCK_ENTITY_TYPE, LureLanternMod.MOD_ID);

    public static final DeferredHolder<BlockEntityType<?>, BlockEntityType<LureLanternBlockEntity>> LURE_LANTERN = BLOCK_ENTITY_TYPES.register(
            "lure_lantern",
            () -> BlockEntityType.Builder.of(LureLanternBlockEntity::new, ModBlocks.LURE_LANTERN.get()).build(null)
    );

    private ModBlockEntities() {
    }

    public static void register(IEventBus eventBus) {
        BLOCK_ENTITY_TYPES.register(eventBus);
    }
}

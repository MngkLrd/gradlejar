package com.kirill.lurelantern.blockentity;

import com.kirill.lurelantern.block.LureLanternBlock;
import com.kirill.lurelantern.registry.ModBlockEntities;
import com.kirill.lurelantern.registry.ModEntityTypeTags;
import net.minecraft.core.BlockPos;
import net.minecraft.world.entity.PathfinderMob;
import net.minecraft.world.entity.animal.TamableAnimal;
import net.minecraft.world.entity.monster.Enemy;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.AABB;

import java.util.List;

public class LureLanternBlockEntity extends BlockEntity {
    private static final int CHECK_INTERVAL_TICKS = 20;
    private static final double RADIUS = 8.0D;
    private static final double ARRIVED_DISTANCE_SQR = 2.25D;
    private static final double WALK_SPEED = 1.15D;

    private int ticksUntilNextCheck = CHECK_INTERVAL_TICKS;

    public LureLanternBlockEntity(BlockPos pos, BlockState blockState) {
        super(ModBlockEntities.LURE_LANTERN.get(), pos, blockState);
    }

    public static void serverTick(Level level, BlockPos pos, BlockState state, LureLanternBlockEntity lantern) {
        if (!state.getValue(LureLanternBlock.ACTIVE)) {
            lantern.ticksUntilNextCheck = CHECK_INTERVAL_TICKS;
            return;
        }

        lantern.ticksUntilNextCheck--;
        if (lantern.ticksUntilNextCheck > 0) {
            return;
        }
        lantern.ticksUntilNextCheck = CHECK_INTERVAL_TICKS;

        double targetX = pos.getX() + 0.5D;
        double targetY = pos.getY();
        double targetZ = pos.getZ() + 0.5D;

        // The AABB is only a broad-phase search. Use a true spherical 8-block
        // radius, not the full 16x16x16 cube's corners.
        AABB lureArea = new AABB(pos).inflate(RADIUS);
        List<PathfinderMob> mobs = level.getEntitiesOfClass(PathfinderMob.class, lureArea, LureLanternBlockEntity::canBeLured);

        for (PathfinderMob mob : mobs) {
            double distance = mob.distanceToSqr(targetX, targetY, targetZ);
            if (distance > RADIUS * RADIUS || distance <= ARRIVED_DISTANCE_SQR) {
                // Do not cancel other AI goals when an animal has arrived.
                continue;
            }

            // This only instructs existing Minecraft pathfinding. The lantern
            // never stores, removes, teleports or respawns any entity.
            mob.getNavigation().moveTo(targetX, targetY, targetZ, WALK_SPEED);
        }
    }

    private static boolean canBeLured(PathfinderMob mob) {
        if (!mob.isAlive()) {
            return false;
        }
        if (mob.isLeashed() || mob.isPassenger() || mob.isVehicle() || mob.isNoAi()) {
            return false;
        }
        if (mob.getType().is(ModEntityTypeTags.LURE_IMMUNE)) {
            return false;
        }
        if (mob.getType().is(ModEntityTypeTags.FORCE_LURABLE)) {
            return true;
        }
        if (mob instanceof Enemy) {
            return false;
        }
        if (mob instanceof TamableAnimal tamableAnimal && tamableAnimal.isOrderedToSit()) {
            return false;
        }

        return !mob.isAggressive();
    }
}

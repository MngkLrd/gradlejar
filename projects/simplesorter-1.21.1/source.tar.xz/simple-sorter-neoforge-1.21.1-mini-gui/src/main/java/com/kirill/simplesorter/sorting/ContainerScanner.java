package com.kirill.simplesorter.sorting;

import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.Container;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.neoforged.neoforge.capabilities.Capabilities;
import net.neoforged.neoforge.items.IItemHandler;
import net.neoforged.neoforge.items.wrapper.InvWrapper;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.IdentityHashMap;
import java.util.List;
import java.util.Set;

public final class ContainerScanner {
    private ContainerScanner() {}

    public static List<ContainerRef> scanRadius(ServerLevel level, Player player, BlockPos center, int radius) {
        int safeRadius = Math.max(1, radius);
        int minX = center.getX() - safeRadius;
        int maxX = center.getX() + safeRadius;
        int minY = Math.max(level.getMinBuildHeight(), center.getY() - safeRadius);
        int maxY = Math.min(level.getMaxBuildHeight() - 1, center.getY() + safeRadius);
        int minZ = center.getZ() - safeRadius;
        int maxZ = center.getZ() + safeRadius;

        return scanBoxInRadius(level, player, new BlockPos(minX, minY, minZ), new BlockPos(maxX, maxY, maxZ), center, safeRadius);
    }

    public static List<ContainerRef> scanBoxInRadius(ServerLevel level, Player player, BlockPos min, BlockPos max, BlockPos center, int radius) {
        List<ContainerRef> result = new ArrayList<>();
        Set<Object> seen = Collections.newSetFromMap(new IdentityHashMap<>());
        int radiusSquared = radius * radius;

        for (BlockPos pos : collectCandidatePositions(level, min, max, center, radiusSquared)) {
            BlockEntity blockEntity = level.getBlockEntity(pos);
            if (blockEntity == null) {
                continue;
            }

            IItemHandler handler = level.getCapability(
                    Capabilities.ItemHandler.BLOCK,
                    pos,
                    level.getBlockState(pos),
                    blockEntity,
                    null
            );

            Object identity = handler != null ? handler : blockEntity;

            if (blockEntity instanceof Container container) {
                if (container.getContainerSize() <= 0) {
                    continue;
                }
                if (handler == null) {
                    handler = new InvWrapper(container);
                    identity = handler;
                }
            }

            if (handler == null || handler.getSlots() <= 0) {
                continue;
            }

            if (!seen.add(identity)) {
                continue;
            }

            result.add(new ContainerRef(pos.immutable(), handler, identity, level));
        }

        return result;
    }

    private static List<BlockPos> collectCandidatePositions(ServerLevel level, BlockPos min, BlockPos max, BlockPos center, int radiusSquared) {
        List<BlockPos> positions = new ArrayList<>();
        int minChunkX = Math.floorDiv(min.getX(), 16);
        int maxChunkX = Math.floorDiv(max.getX(), 16);
        int minChunkZ = Math.floorDiv(min.getZ(), 16);
        int maxChunkZ = Math.floorDiv(max.getZ(), 16);

        for (int chunkX = minChunkX; chunkX <= maxChunkX; chunkX++) {
            for (int chunkZ = minChunkZ; chunkZ <= maxChunkZ; chunkZ++) {
                BlockPos probe = new BlockPos(chunkX << 4, center.getY(), chunkZ << 4);
                if (!level.hasChunkAt(probe)) {
                    continue;
                }

                for (BlockPos pos : level.getChunk(chunkX, chunkZ).getBlockEntitiesPos()) {
                    if (pos.getX() < min.getX() || pos.getX() > max.getX()
                            || pos.getY() < min.getY() || pos.getY() > max.getY()
                            || pos.getZ() < min.getZ() || pos.getZ() > max.getZ()) {
                        continue;
                    }

                    if (!isInsideRadius(center, pos, radiusSquared)) {
                        continue;
                    }

                    positions.add(pos.immutable());
                }
            }
        }

        positions.sort(Comparator.comparingLong(pos -> pos.distSqr(center)));
        int limit = Math.min(positions.size(), 160);
        return positions.subList(0, limit);
    }

    private static boolean isInsideRadius(BlockPos center, BlockPos pos, int radiusSquared) {
        int dx = pos.getX() - center.getX();
        int dy = pos.getY() - center.getY();
        int dz = pos.getZ() - center.getZ();
        return dx * dx + dy * dy + dz * dz <= radiusSquared;
    }
}

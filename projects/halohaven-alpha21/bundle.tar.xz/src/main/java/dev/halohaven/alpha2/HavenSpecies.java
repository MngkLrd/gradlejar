package dev.halohaven.alpha2;

import net.minecraft.world.entity.EntityType;
import net.minecraft.core.registries.BuiltInRegistries;

/** Biome-driven identities; this is not 20 retextured vanilla entities. */
public enum HavenSpecies {
    SUNPUFF("sunpuff", "dawn", Form.ROUND, Mood.PASSIVE, false, 0.53f, 8.0f, 0.23f, 1.0f, 0.6f, 0.65f),
    DAWNSTAG("dawnstag", "dawn", Form.DEER, Mood.NEUTRAL, false, 1.3f, 28.0f, 0.26f, 5.0f, 1.15f, 1.9f),
    POLLENWING("pollenwing", "dawn", Form.MOTH, Mood.PASSIVE, true, 0.62f, 6.0f, 0.28f, 1.0f, 0.56f, 0.5f),
    CHALKSHELL("chalkshell", "chalk", Form.TURTLE, Mood.PASSIVE, false, 0.82f, 22.0f, 0.12f, 2.0f, 0.9f, 0.54f),
    PALEWING("palewing", "chalk", Form.WINGED, Mood.PASSIVE, true, 0.75f, 10.0f, 0.27f, 2.0f, 0.65f, 0.57f),
    RUBBLELURKER("rubblelurker", "chalk", Form.CRAB, Mood.HOSTILE, false, 0.88f, 20.0f, 0.2f, 5.0f, 0.88f, 0.68f),
    CROWNFOX("crownfox", "canopy", Form.FOX, Mood.PASSIVE, false, 0.82f, 12.0f, 0.32f, 2.0f, 0.65f, 0.75f),
    MOSSBACK("mossback", "canopy", Form.BEAST, Mood.PASSIVE, false, 1.65f, 38.0f, 0.16f, 4.0f, 1.25f, 1.25f),
    BARKSTALKER("barkstalker", "canopy", Form.STALKER, Mood.HOSTILE, false, 1.03f, 24.0f, 0.26f, 6.0f, 0.67f, 1.8f),
    CHIMEWING("chimewing", "gorge", Form.BAT, Mood.PASSIVE, true, 0.71f, 8.0f, 0.28f, 1.0f, 0.56f, 0.44f),
    RESONANT("resonant", "gorge", Form.BEAST, Mood.NEUTRAL, false, 1.2f, 34.0f, 0.18f, 7.0f, 1.25f, 1.25f),
    CLIFFPROWLER("cliffprowler", "gorge", Form.CAT, Mood.HOSTILE, false, 1.06f, 25.0f, 0.34f, 7.0f, 0.92f, 0.85f),
    LITTLECHIME("littlechime", "choir", Form.SPIRIT, Mood.PASSIVE, true, 0.65f, 9.0f, 0.23f, 1.0f, 0.5f, 0.85f),
    SILENTCHORISTER("silentchorister", "choir", Form.ROBED, Mood.HOSTILE, false, 1.28f, 30.0f, 0.19f, 6.0f, 0.73f, 2.05f),
    CHOIR_SENTINEL("choir_sentinel", "choir", Form.GOLEM, Mood.NEUTRAL, false, 1.5f, 48.0f, 0.16f, 9.0f, 1.05f, 2.25f),
    VEILMANTA("veilmanta", "veil", Form.MANTA, Mood.PASSIVE, true, 1.35f, 18.0f, 0.21f, 2.0f, 1.65f, 0.48f),
    SHADOWSTALKER("shadowstalker", "veil", Form.SPIDER, Mood.HOSTILE, false, 1.07f, 30.0f, 0.3f, 7.0f, 1.28f, 0.74f),
    MEMORY_WISP("memory_wisp", "veil", Form.WISP, Mood.PASSIVE, true, 0.44f, 6.0f, 0.2f, 1.0f, 0.38f, 0.4f),
    CLOUD_WANDERER("cloud_wanderer", "all", Form.WHALE, Mood.PASSIVE, true, 2.7f, 70.0f, 0.13f, 2.0f, 2.9f, 1.55f),
    SKY_SWALLOW("sky_swallow", "all", Form.BIRD, Mood.PASSIVE, true, 0.42f, 5.0f, 0.32f, 1.0f, 0.38f, 0.44f);
    public enum Form {BAT,BEAST,BIRD,CAT,CRAB,DEER,FOX,GOLEM,MANTA,MOTH,ROBED,ROUND,SPIDER,SPIRIT,STALKER,TURTLE,WHALE,WINGED,WISP}
    public enum Mood { PASSIVE, NEUTRAL, HOSTILE }
    public final String id, biome;
    public final Form form;
    public final Mood mood;
    public final boolean flight;
    public final float scale, health, speed, damage, width, height;
    HavenSpecies(String id, String biome, Form form, Mood mood, boolean flight, float scale,
                 float health, float speed, float damage, float width, float height) {
        this.id=id; this.biome=biome;this.form=form;this.mood=mood;this.flight=flight;
        this.scale=scale;this.health=health;this.speed=speed;this.damage=damage;
        this.width=width;this.height=height;
    }
    public static HavenSpecies of(EntityType<?> type) {
        String id = BuiltInRegistries.ENTITY_TYPE.getKey(type).getPath();
        for (HavenSpecies species:values()) if (species.id.equals(id)) return species;
        throw new IllegalArgumentException("Unregistered Halo Haven species: "+id);
    }
    public boolean dangerous() { return mood==Mood.HOSTILE; }
}

package dev.halohaven.alpha2;

import net.minecraft.core.BlockPos;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.util.Mth;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.*;
import net.minecraft.world.entity.ai.attributes.*;
import net.minecraft.world.entity.ai.control.FlyingMoveControl;
import net.minecraft.world.entity.ai.goal.*;
import net.minecraft.world.entity.ai.goal.target.NearestAttackableTargetGoal;
import net.minecraft.world.entity.ai.navigation.*;
import net.minecraft.world.entity.animal.Animal;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.*;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.LevelReader;
import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraft.world.phys.Vec3;
import org.jetbrains.annotations.Nullable;
import java.util.EnumSet;

/** A single rigorously shared entity implementation with species-specific behavior,
 * environmental responses and geometry. All AI is server authoritative. */
public class HavenCreature extends Animal {
    private final HavenSpecies species;
    private int stirred = 0;
    private int activity = 0;

    public HavenCreature(EntityType<? extends HavenCreature> type, Level level) {
        super(type,level);
        this.species = HavenSpecies.of(type);
        this.getAttribute(Attributes.MAX_HEALTH).setBaseValue(species().health);
        this.getAttribute(Attributes.MOVEMENT_SPEED).setBaseValue(species().speed);
        this.getAttribute(Attributes.ATTACK_DAMAGE).setBaseValue(species().damage);
        this.setHealth(species().health);
        if (species().flight) {
            this.moveControl = new FlyingMoveControl(this, 18, true);
            this.setNoGravity(true);
        }
    }
    public HavenSpecies species(){return species == null ? HavenSpecies.of(getType()) : species;}
    public static AttributeSupplier.Builder createAttributes(){
        return Mob.createMobAttributes().add(Attributes.MAX_HEALTH,24.0)
            .add(Attributes.MOVEMENT_SPEED,.23).add(Attributes.FLYING_SPEED,.25)
            .add(Attributes.ATTACK_DAMAGE,4.0).add(Attributes.FOLLOW_RANGE,20.0);
    }
    @Override protected PathNavigation createNavigation(Level level){
        // Called by base constructor: read from entity type rather than species field.
        if (HavenSpecies.of(getType()).flight) {
            FlyingPathNavigation nav = new FlyingPathNavigation(this,level);
            nav.setCanOpenDoors(false);nav.setCanFloat(true);return nav;
        }
        return new GroundPathNavigation(this,level);
    }
    @Override protected void registerGoals(){
        this.goalSelector.addGoal(0,new FloatGoal(this));
        if (species().mood==HavenSpecies.Mood.HOSTILE) {
            this.goalSelector.addGoal(2,new MeleeAttackGoal(this,1.2,true));
            if(!species().id.equals("shadowstalker")) this.targetSelector.addGoal(1,new NearestAttackableTargetGoal<>(this,Player.class,true));
        } else {
            if (species().mood==HavenSpecies.Mood.PASSIVE) {
                this.goalSelector.addGoal(1,new PanicGoal(this,1.5));
                if (!species().flight) this.goalSelector.addGoal(2,new AvoidEntityGoal<>(this,Player.class,5.0f,1.15,1.35));
            }
            if (isBreedable()) this.goalSelector.addGoal(3,new BreedGoal(this,1.0));
            if (!species().flight) this.goalSelector.addGoal(4,new TemptGoal(this,1.05, net.minecraft.world.item.crafting.Ingredient.of(Items.WHEAT_SEEDS,Items.SWEET_BERRIES),false));
            if (species().mood==HavenSpecies.Mood.NEUTRAL)
                this.goalSelector.addGoal(2,new MeleeAttackGoal(this,1.1,true));
        }
        if (species().flight) this.goalSelector.addGoal(6,new HoverNearbyGoal());
        else if (!species().id.equals("choir_sentinel")) this.goalSelector.addGoal(6,new WaterAvoidingRandomStrollGoal(this,1.0));
        this.goalSelector.addGoal(7,new LookAtPlayerGoal(this,Player.class,7));
        this.goalSelector.addGoal(8,new RandomLookAroundGoal(this));
    }
    private boolean isBreedable() {
        return species().id.equals("sunpuff")||species().id.equals("dawnstag")||
               species().id.equals("chalkshell")||species().id.equals("crownfox");
    }
    @Override public boolean isFood(ItemStack stack) {
        return isBreedable() && (stack.is(Items.WHEAT_SEEDS)||stack.is(Items.SWEET_BERRIES));
    }
    @Nullable @Override public HavenCreature getBreedOffspring(ServerLevel level, AgeableMob partner) {
        return isBreedable()?(HavenCreature)this.getType().create(level):null;
    }
    @Override protected InteractionResult mobInteract(Player player, InteractionHand hand) {
        // Feeding native peaceful fauna uses vanilla animal breeding/age handling.
        return super.mobInteract(player,hand);
    }
    @Override public boolean doHurtTarget(Entity other) {
        return super.doHurtTarget(other);
    }
    @Override public void aiStep() {
        super.aiStep();
        if (species().flight) this.setNoGravity(true);
        if (level().isClientSide()) return;
        if (stirred>0) stirred--;
        if (++activity % 12 == 0) {
            // Resonants respond to running players; crouch to slip past.
            // Sentinels protect the center of a ruin, not the whole dimension.
            if (species().id.equals("resonant") || species().id.equals("choir_sentinel") || species().id.equals("dawnstag")) {
                Player p=level().getNearestPlayer(this, species().id.equals("choir_sentinel")?5.5:8.0);
                if (p!=null && !p.isCreative() && !p.isSpectator()) {
                    boolean alarm=species().id.equals("resonant")?(p.isSprinting()||p.fallDistance>0.6):
                        species().id.equals("choir_sentinel")?this.distanceToSqr(p)<14.0:
                        !level().getEntitiesOfClass(HavenCreature.class,getBoundingBox().inflate(5),e->e!=this && e.isBaby() && e.getType()==getType()).isEmpty() && this.distanceToSqr(p)<9;
                    if (alarm){stirred=160;setTarget(p);}
                }
                if (stirred<=0 && getTarget()!=null) setTarget(null);
            }
        }
        if (activity % 60 == 0) {
            if (species().id.equals("sunpuff") && level() instanceof ServerLevel server)
                server.sendParticles(net.minecraft.core.particles.ParticleTypes.HAPPY_VILLAGER,getX(),getY()+.65,getZ(),2,.25,.15,.25,.005);
            if (species().id.equals("memory_wisp") && level() instanceof ServerLevel server)
                server.sendParticles(net.minecraft.core.particles.ParticleTypes.END_ROD,getX(),getY()+.4,getZ(),2,.23,.2,.23,.01);
            if (species().id.equals("mossback") && level() instanceof ServerLevel server)
                server.sendParticles(net.minecraft.core.particles.ParticleTypes.COMPOSTER,getX(),getY()+1.5,getZ(),1,.4,.1,.4,.01);
        }
        if (activity % 130 == 0 && species().id.equals("pollenwing") && level() instanceof ServerLevel server) {
            // Rare nearby growth tick: actual pollination, no random terrain edits.
            for (int i=0;i<6;i++) {
                BlockPos near=blockPosition().offset(getRandom().nextInt(7)-3,getRandom().nextInt(3)-2,getRandom().nextInt(7)-3);
                var state=server.getBlockState(near);
                if (state.getBlock() instanceof net.minecraft.world.level.block.BonemealableBlock plant
                      && plant.isValidBonemealTarget(server,near,state)) {
                    plant.performBonemeal(server,server.getRandom(),near,state);
                    server.sendParticles(net.minecraft.core.particles.ParticleTypes.HAPPY_VILLAGER,near.getX()+.5,near.getY()+.7,near.getZ()+.5,2,.3,.1,.3,.01);
                    break;
                }
            }
        }
        if (activity % 20 == 0 && species().id.equals("chalkshell")) {
            Player watcher=level().getNearestPlayer(this,4);
            setShiftKeyDown(watcher!=null && !watcher.isSpectator());
            if (watcher!=null) getNavigation().stop();
        }
        if (species().id.equals("cliffprowler") && activity%55==0 && onGround() && getTarget()!=null) {
            Vec3 towards=getTarget().position().subtract(position());
            if (towards.horizontalDistanceSqr()>14 && towards.horizontalDistanceSqr()<75
                    && !level().getBlockState(getTarget().blockPosition().below()).isAir())
                setDeltaMovement(towards.normalize().scale(.47).add(0,.38,0));
        }
        if (species().id.equals("shadowstalker") && activity%16==0) {
            Player p=level().getNearestPlayer(this,9);
            if(p!=null && !p.isCreative() && !p.isSpectator()){
                Vec3 toward=position().subtract(p.position()).normalize();
                // Attacks preferentially from behind or while the player faces away.
                if (p.getLookAngle().dot(toward)<.12) setTarget(p);
            }
        }
        // Idle flock, pair bonding and grazing are handled by the goal selectors.
    }
    @Override public void travel(Vec3 vector){
        if (species().flight && this.isControlledByLocalInstance()) {
            this.moveRelative(this.getSpeed(),vector);
            this.move(MoverType.SELF,this.getDeltaMovement());
            this.setDeltaMovement(this.getDeltaMovement().scale(.90));
        } else super.travel(vector);
    }
    @Override public float getWalkTargetValue(BlockPos pos, LevelReader level) {
        return level.getBlockState(pos.below()).isAir()?-10.0f:super.getWalkTargetValue(pos,level);
    }
    @Override public boolean causeFallDamage(float distance, float modifier, DamageSource source) {
        return species().flight?false:super.causeFallDamage(distance,modifier,source);
    }
    @Override protected SoundEvent getAmbientSound(){
        return switch(species().form) {
            case DEER, FOX, CAT -> SoundEvents.FOX_AMBIENT;
            case BEAST, TURTLE -> SoundEvents.TURTLE_AMBIENT_LAND;
            case BIRD, WINGED, MOTH, BAT -> SoundEvents.PARROT_AMBIENT;
            case GOLEM, CRAB -> SoundEvents.IRON_GOLEM_STEP;
            case STALKER, SPIDER -> SoundEvents.ENDERMITE_AMBIENT;
            default -> SoundEvents.AMETHYST_BLOCK_CHIME;
        };
    }
    @Override protected SoundEvent getHurtSound(DamageSource source){return SoundEvents.AMETHYST_BLOCK_HIT;}
    @Override protected SoundEvent getDeathSound(){return SoundEvents.AMETHYST_BLOCK_BREAK;}
    @Override public float getVoicePitch(){return species().scale>1.5f?.7f:1.1f;}
    private final class HoverNearbyGoal extends Goal {
        private int countdown=0;
        HoverNearbyGoal(){this.setFlags(EnumSet.of(Flag.MOVE));}
        @Override public boolean canUse(){return getTarget()==null && (countdown--<=0 || getNavigation().isDone());}
        @Override public void start(){
            countdown=45+getRandom().nextInt(90);
            BlockPos here=blockPosition();
            for(int tries=0;tries<8;tries++){
                int x=here.getX()+getRandom().nextInt(17)-8;
                int z=here.getZ()+getRandom().nextInt(17)-8;
                int ground=level().getHeight(Heightmap.Types.MOTION_BLOCKING_NO_LEAVES,x,z);
                // No drift beyond an island; never accept a void-height destination.
                if (ground <= level().getMinBuildHeight()+4 || Math.abs(ground-here.getY())>12) continue;
                BlockPos soil=new BlockPos(x,ground-1,z);
                if (level().getBlockState(soil).isAir()) continue;
                int y=ground+2+getRandom().nextInt(5);
                if (!level().getBlockState(new BlockPos(x,y,z)).isAir())continue;
                getNavigation().moveTo(x+.5,y,z+.5,.7);
                break;
            }
        }
        @Override public boolean canContinueToUse(){return !getNavigation().isDone() && countdown>0;}
    }
}

package dev.halohaven.alpha2;

import net.minecraft.world.level.block.*;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.fml.common.Mod;
import net.neoforged.neoforge.registries.DeferredBlock;
import net.neoforged.neoforge.registries.DeferredRegister;
import net.minecraft.world.item.*;
import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.neoforged.neoforge.registries.DeferredHolder;


/** Addon, not a recompiled Halo Haven core. Minecraft 1.21.1 / NeoForge 21.1.x.
 * Original HaloHaven 1.8 classes are left untouched. */
@Mod(HaloHavenAlpha2.MODID)
public final class HaloHavenAlpha2 {
    public static final String MODID = "halohavenalpha2";
    public static final DeferredRegister.Blocks BLOCKS = DeferredRegister.createBlocks(MODID);
    public static final DeferredRegister.Items ITEMS = DeferredRegister.createItems(MODID);
    public static final DeferredBlock<Block> DAWNSTONE_FLAGSTONES = BLOCKS.register("dawnstone_flagstones", () -> new Block(BlockBehaviour.Properties.of().strength(1.6F,6.0F).requiresCorrectToolForDrops()));
    public static final DeferredBlock<Block> DAWNSTONE_COBBLES = BLOCKS.register("dawnstone_cobbles", () -> new Block(BlockBehaviour.Properties.of().strength(1.6F,6.0F).requiresCorrectToolForDrops()));
    public static final DeferredBlock<Block> DAWNSTONE_TRIM = BLOCKS.register("dawnstone_trim", () -> new Block(BlockBehaviour.Properties.of().strength(1.6F,6.0F).requiresCorrectToolForDrops()));
    public static final DeferredBlock<Block> GOLDEN_MARL = BLOCKS.register("golden_marl", () -> new Block(BlockBehaviour.Properties.of().strength(1.6F,6.0F).requiresCorrectToolForDrops()));
    public static final DeferredBlock<Block> BLUSHING_SANDSTONE = BLOCKS.register("blushing_sandstone", () -> new Block(BlockBehaviour.Properties.of().strength(1.6F,6.0F).requiresCorrectToolForDrops()));
    public static final DeferredBlock<Block> ROSE_PAVER = BLOCKS.register("rose_paver", () -> new Block(BlockBehaviour.Properties.of().strength(1.6F,6.0F).requiresCorrectToolForDrops()));
    public static final DeferredBlock<Block> AMBERSTONE_ORE = BLOCKS.register("amberstone_ore", () -> new Block(BlockBehaviour.Properties.of().strength(1.6F,6.0F).requiresCorrectToolForDrops()));
    public static final DeferredBlock<Block> SUNLIT_ROOF_TILES = BLOCKS.register("sunlit_roof_tiles", () -> new Block(BlockBehaviour.Properties.of().strength(1.6F,6.0F).requiresCorrectToolForDrops()));
    public static final DeferredBlock<Block> DAWN_FRESCO = BLOCKS.register("dawn_fresco", () -> new Block(BlockBehaviour.Properties.of().strength(1.6F,6.0F).requiresCorrectToolForDrops()));
    public static final DeferredBlock<Block> DAWN_PILLAR_CAP = BLOCKS.register("dawn_pillar_cap", () -> new Block(BlockBehaviour.Properties.of().strength(1.6F,6.0F).requiresCorrectToolForDrops()));
    public static final DeferredBlock<Block> DAWN_GRASS_TOP = BLOCKS.register("dawn_grass_top", () -> new Block(BlockBehaviour.Properties.of().strength(1.6F,6.0F).requiresCorrectToolForDrops()));
    public static final DeferredBlock<Block> DAWN_HEDGE = BLOCKS.register("dawn_hedge", () -> new Block(BlockBehaviour.Properties.of().strength(1.6F,6.0F).requiresCorrectToolForDrops()));
    public static final DeferredBlock<Block> CHALKSTONE_FLAGSTONES = BLOCKS.register("chalkstone_flagstones", () -> new Block(BlockBehaviour.Properties.of().strength(1.6F,6.0F).requiresCorrectToolForDrops()));
    public static final DeferredBlock<Block> CHALKSTONE_RUBBLE = BLOCKS.register("chalkstone_rubble", () -> new Block(BlockBehaviour.Properties.of().strength(1.6F,6.0F).requiresCorrectToolForDrops()));
    public static final DeferredBlock<Block> CHALK_MARL_SIDE = BLOCKS.register("chalk_marl_side", () -> new Block(BlockBehaviour.Properties.of().strength(1.6F,6.0F).requiresCorrectToolForDrops()));
    public static final DeferredBlock<Block> CHALK_PAVERS = BLOCKS.register("chalk_pavers", () -> new Block(BlockBehaviour.Properties.of().strength(1.6F,6.0F).requiresCorrectToolForDrops()));
    public static final DeferredBlock<Block> CHALK_SLAB_FACE = BLOCKS.register("chalk_slab_face", () -> new Block(BlockBehaviour.Properties.of().strength(1.6F,6.0F).requiresCorrectToolForDrops()));
    public static final DeferredBlock<Block> WEATHERED_CHALKSTONE = BLOCKS.register("weathered_chalkstone", () -> new Block(BlockBehaviour.Properties.of().strength(1.6F,6.0F).requiresCorrectToolForDrops()));
    public static final DeferredBlock<Block> CHALK_ARCH_INLAY = BLOCKS.register("chalk_arch_inlay", () -> new Block(BlockBehaviour.Properties.of().strength(1.6F,6.0F).requiresCorrectToolForDrops()));
    public static final DeferredBlock<Block> FOSSIL_CHALK = BLOCKS.register("fossil_chalk", () -> new Block(BlockBehaviour.Properties.of().strength(1.6F,6.0F).requiresCorrectToolForDrops()));
    public static final DeferredBlock<Block> PALE_ROOF_TILES = BLOCKS.register("pale_roof_tiles", () -> new Block(BlockBehaviour.Properties.of().strength(1.6F,6.0F).requiresCorrectToolForDrops()));
    public static final DeferredBlock<Block> CHALKSTONE_PILLAR_TOP = BLOCKS.register("chalkstone_pillar_top", () -> new Block(BlockBehaviour.Properties.of().strength(1.6F,6.0F).requiresCorrectToolForDrops()));
    public static final DeferredBlock<Block> CHALKGRASS = BLOCKS.register("chalkgrass", () -> new Block(BlockBehaviour.Properties.of().strength(1.6F,6.0F).requiresCorrectToolForDrops()));
    public static final DeferredBlock<Block> CHALK_HEDGE = BLOCKS.register("chalk_hedge", () -> new Block(BlockBehaviour.Properties.of().strength(1.6F,6.0F).requiresCorrectToolForDrops()));
    public static final DeferredBlock<Block> CANOPY_FLAGSTONES = BLOCKS.register("canopy_flagstones", () -> new Block(BlockBehaviour.Properties.of().strength(1.6F,6.0F).requiresCorrectToolForDrops()));
    public static final DeferredBlock<Block> CANOPY_ROOTS = BLOCKS.register("canopy_roots", () -> new Block(BlockBehaviour.Properties.of().strength(1.6F,6.0F).requiresCorrectToolForDrops()));
    public static final DeferredBlock<Block> DARK_CANOPYSTONE = BLOCKS.register("dark_canopystone", () -> new Block(BlockBehaviour.Properties.of().strength(1.6F,6.0F).requiresCorrectToolForDrops()));
    public static final DeferredBlock<Block> CANOPYSTONE_BRICKS = BLOCKS.register("canopystone_bricks", () -> new Block(BlockBehaviour.Properties.of().strength(1.6F,6.0F).requiresCorrectToolForDrops()));
    public static final DeferredBlock<Block> HEARTWOOD_SHINGLES = BLOCKS.register("heartwood_shingles", () -> new Block(BlockBehaviour.Properties.of().strength(1.6F,6.0F).requiresCorrectToolForDrops()));
    public static final DeferredBlock<Block> HANGING_LICHEN = BLOCKS.register("hanging_lichen", () -> new BushBlock(BlockBehaviour.Properties.ofFullCopy(Blocks.SHORT_GRASS).noCollission().noOcclusion()));
    public static final DeferredBlock<Block> FOREST_PAVER = BLOCKS.register("forest_paver", () -> new Block(BlockBehaviour.Properties.of().strength(1.6F,6.0F).requiresCorrectToolForDrops()));
    public static final DeferredBlock<Block> HEARTWOOD_PANEL = BLOCKS.register("heartwood_panel", () -> new Block(BlockBehaviour.Properties.of().strength(1.6F,6.0F).requiresCorrectToolForDrops()));
    public static final DeferredBlock<Block> SAPSTONE_ORE = BLOCKS.register("sapstone_ore", () -> new Block(BlockBehaviour.Properties.of().strength(1.6F,6.0F).requiresCorrectToolForDrops()));
    public static final DeferredBlock<Block> ANCIENT_RINGS = BLOCKS.register("ancient_rings", () -> new Block(BlockBehaviour.Properties.of().strength(1.6F,6.0F).requiresCorrectToolForDrops()));
    public static final DeferredBlock<Block> FERN_CARPET = BLOCKS.register("fern_carpet", () -> new Block(BlockBehaviour.Properties.of().strength(1.6F,6.0F).requiresCorrectToolForDrops()));
    public static final DeferredBlock<Block> EMERALD_LATTICE = BLOCKS.register("emerald_lattice", () -> new Block(BlockBehaviour.Properties.of().strength(1.6F,6.0F).requiresCorrectToolForDrops()));
    public static final DeferredBlock<Block> RINGSTONE_BRICKS = BLOCKS.register("ringstone_bricks", () -> new Block(BlockBehaviour.Properties.of().strength(1.6F,6.0F).requiresCorrectToolForDrops()));
    public static final DeferredBlock<Block> RINGSTONE_FLAGSTONES = BLOCKS.register("ringstone_flagstones", () -> new Block(BlockBehaviour.Properties.of().strength(1.6F,6.0F).requiresCorrectToolForDrops()));
    public static final DeferredBlock<Block> RINGSTONE_CRACKED = BLOCKS.register("ringstone_cracked", () -> new Block(BlockBehaviour.Properties.of().strength(1.6F,6.0F).requiresCorrectToolForDrops()));
    public static final DeferredBlock<Block> GORGE_GRAVEL = BLOCKS.register("gorge_gravel", () -> new Block(BlockBehaviour.Properties.of().strength(1.6F,6.0F).requiresCorrectToolForDrops()));
    public static final DeferredBlock<Block> BASALT_PILLAR_SIDE = BLOCKS.register("basalt_pillar_side", () -> new Block(BlockBehaviour.Properties.of().strength(1.6F,6.0F).requiresCorrectToolForDrops()));
    public static final DeferredBlock<Block> GORGE_IRONWORK = BLOCKS.register("gorge_ironwork", () -> new Block(BlockBehaviour.Properties.of().strength(1.6F,6.0F).requiresCorrectToolForDrops()));
    public static final DeferredBlock<Block> AZURE_COPPER_ORE = BLOCKS.register("azure_copper_ore", () -> new Block(BlockBehaviour.Properties.of().strength(1.6F,6.0F).requiresCorrectToolForDrops()));
    public static final DeferredBlock<Block> ECHO_RUNESTONE = BLOCKS.register("echo_runestone", () -> new Block(BlockBehaviour.Properties.of().strength(1.6F,6.0F).requiresCorrectToolForDrops()));
    public static final DeferredBlock<Block> ECHO_LANTERN_FACE = BLOCKS.register("echo_lantern_face", () -> new Block(BlockBehaviour.Properties.of().strength(1.6F,6.0F).requiresCorrectToolForDrops()));
    public static final DeferredBlock<Block> RESONANT_PAVERS = BLOCKS.register("resonant_pavers", () -> new Block(BlockBehaviour.Properties.of().strength(1.6F,6.0F).requiresCorrectToolForDrops()));
    public static final DeferredBlock<Block> GORGE_PILLAR_CAP = BLOCKS.register("gorge_pillar_cap", () -> new Block(BlockBehaviour.Properties.of().strength(1.6F,6.0F).requiresCorrectToolForDrops()));
    public static final DeferredBlock<Block> STONE_THISTLE = BLOCKS.register("stone_thistle", () -> new BushBlock(BlockBehaviour.Properties.ofFullCopy(Blocks.SHORT_GRASS).noCollission().noOcclusion()));
    public static final DeferredBlock<Block> CHOIRSTONE_FLAGSTONES = BLOCKS.register("choirstone_flagstones", () -> new Block(BlockBehaviour.Properties.of().strength(1.6F,6.0F).requiresCorrectToolForDrops()));
    public static final DeferredBlock<Block> CHOIR_MARBLE = BLOCKS.register("choir_marble", () -> new Block(BlockBehaviour.Properties.of().strength(1.6F,6.0F).requiresCorrectToolForDrops()));
    public static final DeferredBlock<Block> CHOIR_FRIEZE = BLOCKS.register("choir_frieze", () -> new Block(BlockBehaviour.Properties.of().strength(1.6F,6.0F).requiresCorrectToolForDrops()));
    public static final DeferredBlock<Block> CHOIR_ROOF_TILES = BLOCKS.register("choir_roof_tiles", () -> new Block(BlockBehaviour.Properties.of().strength(1.6F,6.0F).requiresCorrectToolForDrops()));
    public static final DeferredBlock<Block> CHOIR_ASH = BLOCKS.register("choir_ash", () -> new Block(BlockBehaviour.Properties.of().strength(1.6F,6.0F).requiresCorrectToolForDrops()));
    public static final DeferredBlock<Block> CHOIR_RELIQUARY = BLOCKS.register("choir_reliquary", () -> new Block(BlockBehaviour.Properties.of().strength(1.6F,6.0F).requiresCorrectToolForDrops()));
    public static final DeferredBlock<Block> CHOIR_PILLAR_TOP = BLOCKS.register("choir_pillar_top", () -> new Block(BlockBehaviour.Properties.of().strength(1.6F,6.0F).requiresCorrectToolForDrops()));
    public static final DeferredBlock<Block> BROKEN_CHOIR_FRESCO = BLOCKS.register("broken_choir_fresco", () -> new Block(BlockBehaviour.Properties.of().strength(1.6F,6.0F).requiresCorrectToolForDrops()));
    public static final DeferredBlock<Block> CHOIR_PAVERS = BLOCKS.register("choir_pavers", () -> new Block(BlockBehaviour.Properties.of().strength(1.6F,6.0F).requiresCorrectToolForDrops()));
    public static final DeferredBlock<Block> CHOIR_GILT = BLOCKS.register("choir_gilt", () -> new Block(BlockBehaviour.Properties.of().strength(1.6F,6.0F).requiresCorrectToolForDrops()));
    public static final DeferredBlock<Block> MOURNING_LEAF = BLOCKS.register("mourning_leaf", () -> new Block(BlockBehaviour.Properties.of().strength(1.6F,6.0F).requiresCorrectToolForDrops()));
    public static final DeferredBlock<Block> CHOIR_GLASS = BLOCKS.register("choir_glass", () -> new GlassBlock(BlockBehaviour.Properties.ofFullCopy(Blocks.GLASS).noOcclusion()));
    public static final DeferredBlock<Block> VEILSTONE_FLAGSTONES = BLOCKS.register("veilstone_flagstones", () -> new Block(BlockBehaviour.Properties.of().strength(1.6F,6.0F).requiresCorrectToolForDrops()));
    public static final DeferredBlock<Block> DEEP_VEILSTONE = BLOCKS.register("deep_veilstone", () -> new Block(BlockBehaviour.Properties.of().strength(1.6F,6.0F).requiresCorrectToolForDrops()));
    public static final DeferredBlock<Block> VEILSTONE_COBBLES = BLOCKS.register("veilstone_cobbles", () -> new Block(BlockBehaviour.Properties.of().strength(1.6F,6.0F).requiresCorrectToolForDrops()));
    public static final DeferredBlock<Block> VEILMUD = BLOCKS.register("veilmud", () -> new Block(BlockBehaviour.Properties.of().strength(1.6F,6.0F).requiresCorrectToolForDrops()));
    public static final DeferredBlock<Block> VEILSTONE_PAVERS = BLOCKS.register("veilstone_pavers", () -> new Block(BlockBehaviour.Properties.of().strength(1.6F,6.0F).requiresCorrectToolForDrops()));
    public static final DeferredBlock<Block> RIFT_INLAY = BLOCKS.register("rift_inlay", () -> new Block(BlockBehaviour.Properties.of().strength(1.6F,6.0F).requiresCorrectToolForDrops()));
    public static final DeferredBlock<Block> SABLE_ROOF_TILES = BLOCKS.register("sable_roof_tiles", () -> new Block(BlockBehaviour.Properties.of().strength(1.6F,6.0F).requiresCorrectToolForDrops()));
    public static final DeferredBlock<Block> VEIL_ASH = BLOCKS.register("veil_ash", () -> new Block(BlockBehaviour.Properties.of().strength(1.6F,6.0F).requiresCorrectToolForDrops()));
    public static final DeferredBlock<Block> UMBRAL_METAL = BLOCKS.register("umbral_metal", () -> new Block(BlockBehaviour.Properties.of().strength(1.6F,6.0F).requiresCorrectToolForDrops()));
    public static final DeferredBlock<Block> VEIL_WARDSTONE = BLOCKS.register("veil_wardstone", () -> new Block(BlockBehaviour.Properties.of().strength(1.6F,6.0F).requiresCorrectToolForDrops()));
    public static final DeferredBlock<Block> VEIL_PILLAR_CAP = BLOCKS.register("veil_pillar_cap", () -> new Block(BlockBehaviour.Properties.of().strength(1.6F,6.0F).requiresCorrectToolForDrops()));
    public static final DeferredBlock<Block> GHOST_MOSS = BLOCKS.register("ghost_moss", () -> new Block(BlockBehaviour.Properties.of().strength(1.6F,6.0F).requiresCorrectToolForDrops()));
    public static final DeferredBlock<Block> DAWNWOOD_LOG = BLOCKS.register("dawnwood_log", () -> new RotatedPillarBlock(BlockBehaviour.Properties.ofFullCopy(Blocks.OAK_LOG).strength(2.0F)));
    public static final DeferredBlock<Block> DAWNWOOD_WOOD = BLOCKS.register("dawnwood_wood", () -> new RotatedPillarBlock(BlockBehaviour.Properties.ofFullCopy(Blocks.OAK_LOG).strength(2.0F)));
    public static final DeferredBlock<Block> DAWNWOOD_STRIPPED_LOG = BLOCKS.register("dawnwood_stripped_log", () -> new RotatedPillarBlock(BlockBehaviour.Properties.ofFullCopy(Blocks.OAK_LOG).strength(2.0F)));
    public static final DeferredBlock<Block> DAWNWOOD_PLANKS = BLOCKS.register("dawnwood_planks", () -> new Block(BlockBehaviour.Properties.of().strength(1.6F,6.0F).requiresCorrectToolForDrops()));
    public static final DeferredBlock<Block> DAWNWOOD_LEAVES = BLOCKS.register("dawnwood_leaves", () -> new LeavesBlock(BlockBehaviour.Properties.ofFullCopy(Blocks.OAK_LEAVES).strength(0.2F).noOcclusion()));
    public static final DeferredBlock<Block> DAWNWOOD_SAPLING = BLOCKS.register("dawnwood_sapling", () -> new BushBlock(BlockBehaviour.Properties.ofFullCopy(Blocks.OAK_SAPLING).noCollission().noOcclusion()));
    public static final DeferredBlock<Block> DAWNWOOD_DOOR_FACE = BLOCKS.register("dawnwood_door_face", () -> new Block(BlockBehaviour.Properties.of().strength(1.6F,6.0F).requiresCorrectToolForDrops()));
    public static final DeferredBlock<Block> DAWNWOOD_TRAPDOOR_FACE = BLOCKS.register("dawnwood_trapdoor_face", () -> new Block(BlockBehaviour.Properties.of().strength(1.6F,6.0F).requiresCorrectToolForDrops()));
    public static final DeferredBlock<Block> HEARTWOOD_LOG = BLOCKS.register("heartwood_log", () -> new RotatedPillarBlock(BlockBehaviour.Properties.ofFullCopy(Blocks.OAK_LOG).strength(2.0F)));
    public static final DeferredBlock<Block> HEARTWOOD_WOOD = BLOCKS.register("heartwood_wood", () -> new RotatedPillarBlock(BlockBehaviour.Properties.ofFullCopy(Blocks.OAK_LOG).strength(2.0F)));
    public static final DeferredBlock<Block> HEARTWOOD_STRIPPED_LOG = BLOCKS.register("heartwood_stripped_log", () -> new RotatedPillarBlock(BlockBehaviour.Properties.ofFullCopy(Blocks.OAK_LOG).strength(2.0F)));
    public static final DeferredBlock<Block> HEARTWOOD_PLANKS = BLOCKS.register("heartwood_planks", () -> new Block(BlockBehaviour.Properties.of().strength(1.6F,6.0F).requiresCorrectToolForDrops()));
    public static final DeferredBlock<Block> HEARTWOOD_LEAVES = BLOCKS.register("heartwood_leaves", () -> new LeavesBlock(BlockBehaviour.Properties.ofFullCopy(Blocks.OAK_LEAVES).strength(0.2F).noOcclusion()));
    public static final DeferredBlock<Block> HEARTWOOD_SAPLING = BLOCKS.register("heartwood_sapling", () -> new BushBlock(BlockBehaviour.Properties.ofFullCopy(Blocks.OAK_SAPLING).noCollission().noOcclusion()));
    public static final DeferredBlock<Block> HEARTWOOD_DOOR_FACE = BLOCKS.register("heartwood_door_face", () -> new Block(BlockBehaviour.Properties.of().strength(1.6F,6.0F).requiresCorrectToolForDrops()));
    public static final DeferredBlock<Block> HEARTWOOD_TRAPDOOR_FACE = BLOCKS.register("heartwood_trapdoor_face", () -> new Block(BlockBehaviour.Properties.of().strength(1.6F,6.0F).requiresCorrectToolForDrops()));
    public static final DeferredBlock<Block> VEILWOOD_LOG = BLOCKS.register("veilwood_log", () -> new RotatedPillarBlock(BlockBehaviour.Properties.ofFullCopy(Blocks.OAK_LOG).strength(2.0F)));
    public static final DeferredBlock<Block> VEILWOOD_WOOD = BLOCKS.register("veilwood_wood", () -> new RotatedPillarBlock(BlockBehaviour.Properties.ofFullCopy(Blocks.OAK_LOG).strength(2.0F)));
    public static final DeferredBlock<Block> VEILWOOD_STRIPPED_LOG = BLOCKS.register("veilwood_stripped_log", () -> new RotatedPillarBlock(BlockBehaviour.Properties.ofFullCopy(Blocks.OAK_LOG).strength(2.0F)));
    public static final DeferredBlock<Block> VEILWOOD_PLANKS = BLOCKS.register("veilwood_planks", () -> new Block(BlockBehaviour.Properties.of().strength(1.6F,6.0F).requiresCorrectToolForDrops()));
    public static final DeferredBlock<Block> VEILWOOD_LEAVES = BLOCKS.register("veilwood_leaves", () -> new LeavesBlock(BlockBehaviour.Properties.ofFullCopy(Blocks.OAK_LEAVES).strength(0.2F).noOcclusion()));
    public static final DeferredBlock<Block> VEILWOOD_SAPLING = BLOCKS.register("veilwood_sapling", () -> new BushBlock(BlockBehaviour.Properties.ofFullCopy(Blocks.OAK_SAPLING).noCollission().noOcclusion()));
    public static final DeferredBlock<Block> VEILWOOD_DOOR_FACE = BLOCKS.register("veilwood_door_face", () -> new Block(BlockBehaviour.Properties.of().strength(1.6F,6.0F).requiresCorrectToolForDrops()));
    public static final DeferredBlock<Block> VEILWOOD_TRAPDOOR_FACE = BLOCKS.register("veilwood_trapdoor_face", () -> new Block(BlockBehaviour.Properties.of().strength(1.6F,6.0F).requiresCorrectToolForDrops()));
    public static final DeferredBlock<Block> DAWNSTONE_BRICKS = BLOCKS.register("dawnstone_bricks", () -> new Block(BlockBehaviour.Properties.of().strength(1.6F,6.0F).requiresCorrectToolForDrops()));
    public static final DeferredBlock<Block> POLISHED_DAWNSTONE = BLOCKS.register("polished_dawnstone", () -> new Block(BlockBehaviour.Properties.of().strength(1.6F,6.0F).requiresCorrectToolForDrops()));
    public static final DeferredBlock<Block> SUNSTONE_INLAY = BLOCKS.register("sunstone_inlay", () -> new Block(BlockBehaviour.Properties.of().strength(1.6F,6.0F).requiresCorrectToolForDrops()));
    public static final DeferredBlock<Block> DAWNWOOD_BARK = BLOCKS.register("dawnwood_bark", () -> new Block(BlockBehaviour.Properties.of().strength(1.6F,6.0F).requiresCorrectToolForDrops()));
    public static final DeferredBlock<Block> CHALKSTONE_BRICKS = BLOCKS.register("chalkstone_bricks", () -> new Block(BlockBehaviour.Properties.of().strength(1.6F,6.0F).requiresCorrectToolForDrops()));
    public static final DeferredBlock<Block> POLISHED_CHALKSTONE = BLOCKS.register("polished_chalkstone", () -> new Block(BlockBehaviour.Properties.of().strength(1.6F,6.0F).requiresCorrectToolForDrops()));
    public static final DeferredBlock<Block> CHALKSTONE_COLUMN = BLOCKS.register("chalkstone_column", () -> new Block(BlockBehaviour.Properties.of().strength(1.6F,6.0F).requiresCorrectToolForDrops()));
    public static final DeferredBlock<Block> CHALK_MARL = BLOCKS.register("chalk_marl", () -> new Block(BlockBehaviour.Properties.of().strength(1.6F,6.0F).requiresCorrectToolForDrops()));
    public static final DeferredBlock<Block> CHALK_LICHEN = BLOCKS.register("chalk_lichen", () -> new LeavesBlock(BlockBehaviour.Properties.ofFullCopy(Blocks.OAK_LEAVES).strength(0.2F).noOcclusion()));
    public static final DeferredBlock<Block> CHALKSTONE_CARVED = BLOCKS.register("chalkstone_carved", () -> new Block(BlockBehaviour.Properties.of().strength(1.6F,6.0F).requiresCorrectToolForDrops()));
    public static final DeferredBlock<Block> CANOPY_MOSS = BLOCKS.register("canopy_moss", () -> new Block(BlockBehaviour.Properties.of().strength(1.6F,6.0F).requiresCorrectToolForDrops()));
    public static final DeferredBlock<Block> CANOPY_FOLIAGE = BLOCKS.register("canopy_foliage", () -> new LeavesBlock(BlockBehaviour.Properties.ofFullCopy(Blocks.OAK_LEAVES).strength(0.2F).noOcclusion()));
    public static final DeferredBlock<Block> CANOPYSTONE = BLOCKS.register("canopystone", () -> new Block(BlockBehaviour.Properties.of().strength(1.6F,6.0F).requiresCorrectToolForDrops()));
    public static final DeferredBlock<Block> RESONANT_SHALE_BRICKS = BLOCKS.register("resonant_shale_bricks", () -> new Block(BlockBehaviour.Properties.of().strength(1.6F,6.0F).requiresCorrectToolForDrops()));
    public static final DeferredBlock<Block> FRACTURED_RESONANT_SHALE = BLOCKS.register("fractured_resonant_shale", () -> new Block(BlockBehaviour.Properties.of().strength(1.6F,6.0F).requiresCorrectToolForDrops()));
    public static final DeferredBlock<Block> ECHO_CRYSTAL_ORE = BLOCKS.register("echo_crystal_ore", () -> new Block(BlockBehaviour.Properties.of().strength(1.6F,6.0F).requiresCorrectToolForDrops()));
    public static final DeferredBlock<Block> ECHO_CRYSTAL_CLUSTER = BLOCKS.register("echo_crystal_cluster", () -> new Block(BlockBehaviour.Properties.of().strength(1.6F,6.0F).requiresCorrectToolForDrops()));
    public static final DeferredBlock<Block> GORGE_BASALT = BLOCKS.register("gorge_basalt", () -> new Block(BlockBehaviour.Properties.of().strength(1.6F,6.0F).requiresCorrectToolForDrops()));
    public static final DeferredBlock<Block> RINGSTONE_COLUMN = BLOCKS.register("ringstone_column", () -> new Block(BlockBehaviour.Properties.of().strength(1.6F,6.0F).requiresCorrectToolForDrops()));
    public static final DeferredBlock<Block> CHOIRSTONE_BRICKS = BLOCKS.register("choirstone_bricks", () -> new Block(BlockBehaviour.Properties.of().strength(1.6F,6.0F).requiresCorrectToolForDrops()));
    public static final DeferredBlock<Block> CHOIR_INLAY = BLOCKS.register("choir_inlay", () -> new Block(BlockBehaviour.Properties.of().strength(1.6F,6.0F).requiresCorrectToolForDrops()));
    public static final DeferredBlock<Block> CHOIR_COLUMN = BLOCKS.register("choir_column", () -> new Block(BlockBehaviour.Properties.of().strength(1.6F,6.0F).requiresCorrectToolForDrops()));
    public static final DeferredBlock<Block> CRACKED_CHOIRSTONE = BLOCKS.register("cracked_choirstone", () -> new Block(BlockBehaviour.Properties.of().strength(1.6F,6.0F).requiresCorrectToolForDrops()));
    public static final DeferredBlock<Block> CHOIR_LANTERN = BLOCKS.register("choir_lantern", () -> new Block(BlockBehaviour.Properties.of().strength(1.6F,6.0F).requiresCorrectToolForDrops()));
    public static final DeferredBlock<Block> POLISHED_CHOIRSTONE = BLOCKS.register("polished_choirstone", () -> new Block(BlockBehaviour.Properties.of().strength(1.6F,6.0F).requiresCorrectToolForDrops()));
    public static final DeferredBlock<Block> VEILSTONE_BRICKS = BLOCKS.register("veilstone_bricks", () -> new Block(BlockBehaviour.Properties.of().strength(1.6F,6.0F).requiresCorrectToolForDrops()));
    public static final DeferredBlock<Block> FRACTURED_VEILSTONE = BLOCKS.register("fractured_veilstone", () -> new Block(BlockBehaviour.Properties.of().strength(1.6F,6.0F).requiresCorrectToolForDrops()));
    public static final DeferredBlock<Block> VEILGLASS = BLOCKS.register("veilglass", () -> new GlassBlock(BlockBehaviour.Properties.ofFullCopy(Blocks.GLASS).noOcclusion()));
    public static final DeferredBlock<Block> VEILROOT = BLOCKS.register("veilroot", () -> new Block(BlockBehaviour.Properties.of().strength(1.6F,6.0F).requiresCorrectToolForDrops()));
    public static final DeferredBlock<Block> VEIL_STARMETAL = BLOCKS.register("veil_starmetal", () -> new Block(BlockBehaviour.Properties.of().strength(1.6F,6.0F).requiresCorrectToolForDrops()));

    public static final DeferredRegister<CreativeModeTab> TABS = DeferredRegister.create(Registries.CREATIVE_MODE_TAB, MODID);
    public static final DeferredHolder<CreativeModeTab, CreativeModeTab> MAIN_TAB = TABS.register("main", () ->
        CreativeModeTab.builder()
            .title(Component.translatable("itemGroup.halohavenalpha2"))
            .icon(() -> new ItemStack(DAWNWOOD_LOG.get()))
            .displayItems((params, out) -> {
                for (var entry : BLOCKS.getEntries()) out.accept(entry.get());
                for (HavenSpecies s : HavenSpecies.values()) out.accept(ITEMS.getEntries().stream().filter(i->i.getId().getPath().equals(s.id+"_spawn_egg")).findFirst().orElseThrow().get());
            }).build());

    public HaloHavenAlpha2(IEventBus bus) {
        BLOCKS.register(bus);
        for (var block : BLOCKS.getEntries()) {
            ITEMS.register(block.getId().getPath(), () -> new BlockItem(block.get(), new Item.Properties()));
        }
        HavenEntities.register(bus);
        ITEMS.register(bus);
        TABS.register(bus);
    }
}

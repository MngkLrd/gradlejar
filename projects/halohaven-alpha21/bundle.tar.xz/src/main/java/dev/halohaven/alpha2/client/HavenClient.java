package dev.halohaven.alpha2.client;

import dev.halohaven.alpha2.*;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import net.minecraft.client.model.*;
import net.minecraft.client.model.geom.*;
import net.minecraft.client.model.geom.builders.*;
import net.minecraft.client.renderer.entity.*;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.client.event.EntityRenderersEvent;
import java.util.LinkedHashMap;
import java.util.Map;

/** Twenty separately baked voxel outlines (antlers, limbs, wings, tails, shells, mantas). */
@EventBusSubscriber(modid=HaloHavenAlpha2.MODID,bus=EventBusSubscriber.Bus.MOD,value=Dist.CLIENT)
public final class HavenClient {
    public static final Map<String,ModelLayerLocation> LAYERS=new LinkedHashMap<>();
    static {for(HavenSpecies s:HavenSpecies.values()) LAYERS.put(s.id,new ModelLayerLocation(ResourceLocation.fromNamespaceAndPath(HaloHavenAlpha2.MODID,s.id),"main"));}
    @SubscribeEvent public static void layers(EntityRenderersEvent.RegisterLayerDefinitions e){
        for(HavenSpecies s:HavenSpecies.values()) e.registerLayerDefinition(LAYERS.get(s.id),()->HavenMobModel.layer(s));
    }
    @SubscribeEvent public static void renderers(EntityRenderersEvent.RegisterRenderers e){
        for(HavenSpecies s:HavenSpecies.values()) e.registerEntityRenderer(HavenEntities.MOBS.get(s.id).get(),ctx->new HavenRenderer(ctx,s));
    }
    public static class HavenRenderer extends MobRenderer<HavenCreature,HavenMobModel> {
        private final HavenSpecies species;
        public HavenRenderer(EntityRendererProvider.Context ctx,HavenSpecies s){
            super(ctx,new HavenMobModel(ctx.bakeLayer(LAYERS.get(s.id)),s),Math.min(.9f,.22f*s.scale));this.species=s;
        }
        @Override public ResourceLocation getTextureLocation(HavenCreature e){
            return ResourceLocation.fromNamespaceAndPath(HaloHavenAlpha2.MODID,"textures/entity/"+species.id+".png");
        }
        @Override protected void scale(HavenCreature e, PoseStack stack, float ticks){stack.scale(species.scale,species.scale,species.scale);}
    }
    public static class HavenMobModel extends EntityModel<HavenCreature> {
        private final HavenSpecies species;
        private final ModelPart modelRoot;
        private final ModelPart body,head,frontLeft,frontRight,backLeft,backRight,wingLeft,wingRight,tail;
        public HavenMobModel(ModelPart root,HavenSpecies s){this.modelRoot=root;this.species=s;
            body=root.getChild("body");head=root.getChild("head");
            frontLeft=root.getChild("frontLeft");frontRight=root.getChild("frontRight");
            backLeft=root.getChild("backLeft");backRight=root.getChild("backRight");
            wingLeft=root.getChild("wingLeft");wingRight=root.getChild("wingRight");tail=root.getChild("tail");
        }
        private static PartDefinition add(PartDefinition root,String id,CubeListBuilder b,int x,int y,int z){
            return root.addOrReplaceChild(id,b,PartPose.offset(x,y,z));
        }
        public static LayerDefinition layer(HavenSpecies s){
            MeshDefinition mesh=new MeshDefinition();PartDefinition root=mesh.getRoot();
            boolean tall=s.form==HavenSpecies.Form.ROBED || s.form==HavenSpecies.Form.GOLEM || s.form==HavenSpecies.Form.STALKER;
            boolean wide=s.form==HavenSpecies.Form.MANTA || s.form==HavenSpecies.Form.WHALE;
            boolean shell=s.form==HavenSpecies.Form.TURTLE || s.form==HavenSpecies.Form.CRAB;
            int bw=wide?17:s.form==HavenSpecies.Form.BEAST?13: s.form==HavenSpecies.Form.GOLEM?11:9;
            int bh=tall?13:shell?6:wide?6:8;
            int bd=wide?11:shell?12:s.form==HavenSpecies.Form.BEAST?13:10;
            int by=tall?10:13;
            PartDefinition body=add(root,"body",CubeListBuilder.create().texOffs(0,18).addBox(-bw/2f,-bh/2f,-bd/2f,bw,bh,bd),0,by,0);
            int headY=tall?-8:-4;
            add(root,"head",CubeListBuilder.create().texOffs(0,0).addBox(-4,-4,-6,8,8,7),0,by+headY,-bd/2);
            int legH=tall?10:7;
            if (wide)legH=1;
            for(int i=0;i<4;i++){
                int x=i%2==0?-(bw/2-2):(bw/2-2),z=i<2?-(bd/2-2):(bd/2-2);
                add(root,i==0?"frontLeft":i==1?"frontRight":i==2?"backLeft":"backRight",
                    CubeListBuilder.create().texOffs(64,0).addBox(-2,0,-2,4,legH,4),x,by+(bh/2)-1,z);
            }
            int ww=s.form==HavenSpecies.Form.MANTA?17:s.form==HavenSpecies.Form.WHALE?13:10;
            int wd=s.form==HavenSpecies.Form.MANTA?12:8;
            add(root,"wingLeft",CubeListBuilder.create().texOffs(64,20).addBox(0,-1,0,ww,2,wd),bw/2,by-3,-3);
            add(root,"wingRight",CubeListBuilder.create().texOffs(64,20).mirror().addBox(-ww,-1,0,ww,2,wd),-bw/2,by-3,-3);
            add(root,"tail",CubeListBuilder.create().texOffs(64,40).addBox(-2,-2,0,4,4,8),0,by,-bd/2+bd);
            if(s.form==HavenSpecies.Form.DEER || s.form==HavenSpecies.Form.GOLEM){
                add(root,"hornLeft",CubeListBuilder.create().texOffs(96,42).addBox(-1,-9,-1,2,9,2),-3,by+headY-5,-bd/2);
                add(root,"hornRight",CubeListBuilder.create().texOffs(96,42).addBox(-1,-9,-1,2,9,2),3,by+headY-5,-bd/2);
                if(s.form==HavenSpecies.Form.DEER){
                    add(root,"branchLeft",CubeListBuilder.create().texOffs(110,42).addBox(-5,-2,0,6,2,2),-3,by+headY-9,-bd/2);
                    add(root,"branchRight",CubeListBuilder.create().texOffs(110,42).addBox(0,-2,0,6,2,2),3,by+headY-9,-bd/2);
                }
            }
            if(shell){add(body,"shell",CubeListBuilder.create().texOffs(0,18).addBox(-bw/2f,-bh/2f-3,-bd/2f,bw,bh/2f+2,bd),0,0,0);}
            if(s.form==HavenSpecies.Form.SPIDER){
                for(int i=0;i<4;i++){
                    int z=i*3-5;
                    add(root,"legExtraL"+i,CubeListBuilder.create().texOffs(64,0).addBox(0,0,-1,9,2,2),bw/2,by,z);
                    add(root,"legExtraR"+i,CubeListBuilder.create().texOffs(64,0).addBox(-9,0,-1,9,2,2),-bw/2,by,z);
                }
            }
            // Each family carries its anatomy in-game: not twenty identical square animals.
            if(s.form==HavenSpecies.Form.ROUND){
                add(root,"earLeft",CubeListBuilder.create().texOffs(96,42).addBox(-1,-6,-1,2,7,2),-3,by+headY-3,-bd/2);
                add(root,"earRight",CubeListBuilder.create().texOffs(96,42).addBox(-1,-6,-1,2,7,2),3,by+headY-3,-bd/2);
            }
            if(s.form==HavenSpecies.Form.FOX || s.form==HavenSpecies.Form.CAT){
                add(root,"earLeft",CubeListBuilder.create().texOffs(96,42).addBox(-1,-4,-1,2,4,2),-3,by+headY-3,-bd/2);
                add(root,"earRight",CubeListBuilder.create().texOffs(96,42).addBox(-1,-4,-1,2,4,2),3,by+headY-3,-bd/2);
            }
            if(s.form==HavenSpecies.Form.BEAST || s.form==HavenSpecies.Form.GOLEM){
                for(int i=0;i<3;i++)add(body,"ridge"+i,CubeListBuilder.create().texOffs(96,42)
                    .addBox(-1,-6,-1,2,6,2),-3+i*3,-bh/2,-bd/3+i*2);
            }
            if(s.form==HavenSpecies.Form.MOTH || s.form==HavenSpecies.Form.BAT){
                add(root,"feelerLeft",CubeListBuilder.create().texOffs(96,42).addBox(-1,-5,-1,2,5,2),-3,by+headY-3,-bd/2);
                add(root,"feelerRight",CubeListBuilder.create().texOffs(96,42).addBox(-1,-5,-1,2,5,2),3,by+headY-3,-bd/2);
            }
            if(s.form==HavenSpecies.Form.SPIRIT || s.form==HavenSpecies.Form.WISP){
                add(root,"crownLeft",CubeListBuilder.create().texOffs(96,42).addBox(-1,-6,-1,2,6,2),-4,by+headY-2,-bd/2);
                add(root,"crownRight",CubeListBuilder.create().texOffs(96,42).addBox(-1,-6,-1,2,6,2),4,by+headY-2,-bd/2);
            }
            return LayerDefinition.create(mesh,128,128);
        }
        @Override public void renderToBuffer(PoseStack poseStack, VertexConsumer buffer, int light, int overlay, int color){
            modelRoot.render(poseStack,buffer,light,overlay,color);
        }
        @Override public void setupAnim(HavenCreature mob,float limbSwing,float limbSwingAmount,float ageInTicks,float netHeadYaw,float headPitch){
            float walk=Mth.cos(limbSwing*.65f)*limbSwingAmount*.75f;
            frontLeft.xRot=walk;frontRight.xRot=-walk;backLeft.xRot=-walk;backRight.xRot=walk;
            boolean legs = !species.flight || species.form==HavenSpecies.Form.BIRD || species.form==HavenSpecies.Form.WINGED;
            frontLeft.visible=frontRight.visible=backLeft.visible=backRight.visible=legs;
            head.xRot=headPitch*(Mth.PI/180f);head.yRot=netHeadYaw*(Mth.PI/180f);
            float flap=Mth.sin(ageInTicks*(species.form==HavenSpecies.Form.BIRD?.9f:.32f));
            wingLeft.zRot=species.flight?(flap*.5f+.10f):0;wingRight.zRot=species.flight?-(flap*.5f+.10f):0;
            wingLeft.visible=species.flight || species.form==HavenSpecies.Form.FOX;
            wingRight.visible=wingLeft.visible;
            body.xRot=species.flight?.04f*Mth.sin(ageInTicks*.2f):0;
            body.y=species.flight?13+Mth.sin(ageInTicks*.13f)*.6f:13;
            tail.yRot=Mth.sin(ageInTicks*.16f)*.25f;
        }
    }
}

package dev.halohaven.alpha2;

import java.util.LinkedHashMap;
import java.util.Map;
import net.minecraft.core.registries.Registries;
import net.minecraft.world.entity.*;
import net.minecraft.world.item.*;
import net.neoforged.neoforge.registries.*;
import net.neoforged.neoforge.event.entity.EntityAttributeCreationEvent;
import net.neoforged.neoforge.event.entity.RegisterSpawnPlacementsEvent;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.minecraft.world.level.levelgen.Heightmap;

/** Central registry + spawn eggs and on-ground spawn placement for sky islands. */
@EventBusSubscriber(modid=HaloHavenAlpha2.MODID,bus=EventBusSubscriber.Bus.MOD)
public final class HavenEntities {
    private HavenEntities(){}
    public static final DeferredRegister<EntityType<?>> TYPES = DeferredRegister.create(Registries.ENTITY_TYPE,HaloHavenAlpha2.MODID);
    public static final Map<String,DeferredHolder<EntityType<?>,EntityType<HavenCreature>>> MOBS=new LinkedHashMap<>();
    static {
        for(HavenSpecies s:HavenSpecies.values()){
            MobCategory category=s.dangerous()?MobCategory.MONSTER:MobCategory.CREATURE;
            MOBS.put(s.id,TYPES.register(s.id,()->EntityType.Builder.of(HavenCreature::new,category)
                .sized(s.width,s.height).clientTrackingRange(s.id.equals("cloud_wanderer")?12:8)
                .build(HaloHavenAlpha2.MODID+":"+s.id)));
        }
    }
    public static void register(net.neoforged.bus.api.IEventBus bus){
        TYPES.register(bus);
        for(HavenSpecies s:HavenSpecies.values()){
            String name=s.id+"_spawn_egg";
            HaloHavenAlpha2.ITEMS.register(name,()->new SpawnEggItem(MOBS.get(s.id).get(),eggColor(s.id,false),eggColor(s.id,true),new Item.Properties()));
        }
    }
    private static int eggColor(String id,boolean accent) {
        int h=id.hashCode();int v=(h^(h>>>11))&0xFFFFFF;
        return accent? (v ^ 0xA0C9AC)&0xFFFFFF : v;
    }
    @SubscribeEvent public static void attributes(EntityAttributeCreationEvent event){
        for(var entry:MOBS.values()) event.put(entry.get(),HavenCreature.createAttributes().build());
    }
    @SubscribeEvent public static void spawns(RegisterSpawnPlacementsEvent event){
        for(var entry:MOBS.values()){
            event.register(entry.get(),SpawnPlacementTypes.ON_GROUND,Heightmap.Types.MOTION_BLOCKING_NO_LEAVES,
               (type,world,reason,pos,random)->{
                   // Hard stop against void: terrain below must be sturdy and target space unobstructed.
                   return world.getBlockState(pos.below()).isFaceSturdy(world,pos.below(),net.minecraft.core.Direction.UP)
                       && world.getBlockState(pos).isAir() && world.getBlockState(pos.above()).isAir()
                       && (world.getRawBrightness(pos,0)>5);
               },RegisterSpawnPlacementsEvent.Operation.REPLACE);
        }
    }
}

# Last Witness 0.1.0

**Minecraft 1.21.1 | NeoForge 21.1.262 | Java 21 | server-side gameplay mod**

A compact Wild West crime/witness mechanic. No new tools, items, blocks, textures, GUIs, power systems, thirst meters or magic.

## Gameplay

1. Hit a villager or village iron golem, or break a bell while a villager can see or hear you.
2. A nearby adult villager becomes a **witness**; the action bar warns you.
3. The witness tries to reach their village bell. The bell report goes through upon reaching it. If no bell is available, they can tell a nearby villager after a delay.
4. You can stop the report by removing the witness before it reaches the bell, leaving it stranded without anyone to tell if there is no bell, or by **sneaking + right-clicking the witness with a sword or axe** within 3.5 blocks. Threats have a 70% chance to work **only** if no other adult villagers are within 8 blocks. Otherwise, the report is immediate.
5. Once reported, the nearby village remembers your face for 4 real-time minutes of loaded-server game time. Iron golems pursue you locally and villagers refuse to trade. Leave the area until the heat dies down.

Important: you may see vanilla golem aggression immediately if you attack its protected villagers; that is normal vanilla behavior, separate from this mod's reporting process.

## Build

This is an independent project for the existing [`MngkLrd/gradlejar`](https://github.com/MngkLrd/gradlejar) build hub, placed at `projects/last-witness/`. Its `build-profile.json` is compatible with the hub's project contract.

* Java: **21**
* CI Gradle: **9.2.1** (follows hub profile)
* NeoForge: **21.1.262**
* IDE: IntelliJ IDEA
* Build: `gradle --no-daemon clean build`
* Output: `build/libs/lastwitness-1.21.1-0.1.0.jar`

For the GitHub CI workflow, run **Minecraft Mod Build Hub** with `project_dir: projects/last-witness` after uploading the project to that directory.

## Config

After creating or joining a world, modify `serverconfig/lastwitness-server.toml` in the world/server config directory:

* `witnesses.noticeRadius = 20`
* `witnesses.reportSeconds = 10`
* `witnesses.enableIntimidation = true`
* `witnesses.bellVandalism = true`
* `wanted.wantedSeconds = 240`
* `wanted.wantedRadius = 48`

## Testing checklist

- [ ] Boot a new world with 1.21.1 NeoForge and the JAR.
- [ ] Hit a villager when a second adult villager is close; see the warning.
- [ ] Observe witness heading toward a nearby village bell, and hear the bell report.
- [ ] Right-click a merchant after a report. Trading should be blocked near the alarm.
- [ ] Let a golem notice you while wanted. It should pursue you.
- [ ] Create a second incident, then threaten an isolated witness by sneak-right-clicking with a sword.
- [ ] Threaten a witness standing near other villagers. The attempt should fail.
- [ ] Kill the sole witness before the report; no mod report should occur.
- [ ] Leave the village and return after the configured cooldown, trading should work again.
- [ ] Save/reload the world during a wanted period; the reported wanted state should persist.
- [ ] Run on a dedicated server without installing this JAR on the client (server-only check).

## Constraints / limitations

* This is an **MVP/beta**; witness navigation can be interrupted by Minecraft villager AI. It retries every second.
* A villager who cannot reach the bell can report to another nearby villager when the timer elapses. If isolated, the lead goes cold.
* Per-player wanted records persist across world saves/restarts, but **unreported active witness cases do not**.
* Attacking a villager may still trigger ordinary vanilla golem retaliation even with no witnesses.
* The game has no ownership concept for bells. Breaking one near any villager can be treated as vandalism.
* Actions that would be canceled by other mods may still be noticed if canceled later in the event pipeline.
* All detection runs on the server, scans nearby **loaded** villagers, and never forces chunk loading.
* Build and startup must be verified using real NeoForge dependencies and an in-game test before a production release.

## Future

Prototype → MVP (this release) → playable alpha (multiple independent witnesses, fleeing AI) → expansion (theft and property claims, posse/sheriff) → polish (in-world indications) → compatibility and performance.

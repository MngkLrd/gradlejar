package dev.minemods.lastwitness.crime;

import dev.minemods.lastwitness.config.WitnessConfig;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.animal.IronGolem;
import net.minecraft.world.entity.npc.Villager;
import net.minecraft.world.item.AxeItem;
import net.minecraft.world.item.SwordItem;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.neoforge.event.entity.living.LivingDamageEvent;
import net.neoforged.neoforge.event.entity.player.PlayerInteractEvent;
import net.neoforged.neoforge.event.level.BlockEvent;
import net.neoforged.neoforge.event.tick.ServerTickEvent;

/** Only world/server events; nothing depends on client-only Minecraft classes. */
public final class CrimeEvents {
    @SubscribeEvent
    public void onHurt(LivingDamageEvent.Post event) {
        if (!(event.getEntity().level() instanceof ServerLevel)) return;
        if (event.getNewDamage() <= 0) return;
        if (!(event.getEntity() instanceof Villager || event.getEntity() instanceof IronGolem)) return;
        if (!(event.getSource().getEntity() instanceof ServerPlayer player)) return;
        WitnessManager.registerCrime(player, event.getEntity().blockPosition(), event.getEntity());
    }

    @SubscribeEvent
    public void onBellBroken(BlockEvent.BreakEvent event) {
        if (!WitnessConfig.BELL_VANDALISM.get()) return;
        if (!event.getState().is(Blocks.BELL) || event.isCanceled()) return;
        if (!(event.getPlayer() instanceof ServerPlayer player)) return;
        if (!(event.getLevel() instanceof ServerLevel)) return;
        WitnessManager.registerCrime(player, event.getPos(), null);
    }

    @SubscribeEvent
    public void onVillagerInteraction(PlayerInteractEvent.EntityInteract event) {
        if (!(event.getEntity() instanceof ServerPlayer player)) return;
        if (!(event.getTarget() instanceof Villager villager)) return;

        if (WitnessConfig.INTIMIDATION.get() && player.isShiftKeyDown()
                && (player.getItemInHand(event.getHand()).getItem() instanceof SwordItem
                    || player.getItemInHand(event.getHand()).getItem() instanceof AxeItem)
                && WitnessManager.isWitnessFor(player, villager)) {
            WitnessManager.intimidate(player, villager);
            event.setCancellationResult(InteractionResult.SUCCESS);
            event.setCanceled(true);
            return;
        }

        if (WitnessManager.wantedHere(player)) {
            WitnessManager.say(player, "message.lastwitness.no_trade");
            event.setCancellationResult(InteractionResult.SUCCESS);
            event.setCanceled(true);
        }
    }

    @SubscribeEvent
    public void onServerTick(ServerTickEvent.Post event) {
        WitnessManager.tick(event);
    }
}

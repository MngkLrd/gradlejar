package dev.minemods.lastwitness.crime;

import net.minecraft.core.BlockPos;
import net.minecraft.resources.ResourceKey;
import net.minecraft.world.level.Level;

import java.util.UUID;

/** One ongoing, unresolved accusation against a player. Server memory only. */
public record WitnessCase(UUID suspect, UUID witness, ResourceKey<Level> dimension,
                          BlockPos crimePos, BlockPos bellPos, long startedAt,
                          long deadline, long lastPathAt) {
    public WitnessCase withLastPathAt(long tick) {
        return new WitnessCase(suspect, witness, dimension, crimePos, bellPos, startedAt, deadline, tick);
    }
}

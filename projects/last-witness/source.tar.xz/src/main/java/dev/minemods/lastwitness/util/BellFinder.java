package dev.minemods.lastwitness.util;

import net.minecraft.core.BlockPos;
import net.minecraft.core.GlobalPos;
import net.minecraft.world.entity.ai.memory.MemoryModuleType;
import net.minecraft.world.entity.npc.Villager;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.server.level.ServerLevel;

import java.util.Optional;

/** Runs only once when a case is opened, never in the regular tick loop. */
public final class BellFinder {
    private BellFinder() {}

    public static BlockPos find(ServerLevel level, Villager villager) {
        Optional<GlobalPos> poi = villager.getBrain().getMemory(MemoryModuleType.MEETING_POINT);
        if (poi.isPresent() && poi.get().dimension().equals(level.dimension())) {
            BlockPos pos = poi.get().pos();
            if (level.hasChunkAt(pos) && level.getBlockState(pos).is(Blocks.BELL)) {
                return pos.immutable();
            }
        }

        BlockPos origin = villager.blockPosition();
        BlockPos.MutableBlockPos cursor = new BlockPos.MutableBlockPos();
        BlockPos best = null;
        double bestDist = Double.MAX_VALUE;
        // A deliberately bounded search; this never forces chunks to load.
        for (int dy = -4; dy <= 4; dy++) {
            for (int dx = -12; dx <= 12; dx++) {
                for (int dz = -12; dz <= 12; dz++) {
                    cursor.set(origin.getX() + dx, origin.getY() + dy, origin.getZ() + dz);
                    if (!level.hasChunkAt(cursor) || !level.getBlockState(cursor).is(Blocks.BELL)) continue;
                    double dist = cursor.distSqr(origin);
                    if (dist < bestDist) {
                        best = cursor.immutable();
                        bestDist = dist;
                    }
                }
            }
        }
        return best;
    }
}

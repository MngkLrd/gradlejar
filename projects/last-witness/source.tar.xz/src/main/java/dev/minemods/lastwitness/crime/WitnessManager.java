package dev.minemods.lastwitness.crime;

import dev.minemods.lastwitness.config.WitnessConfig;
import dev.minemods.lastwitness.data.WantedData;
import dev.minemods.lastwitness.util.BellFinder;
import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.animal.IronGolem;
import net.minecraft.world.entity.npc.Villager;
import net.minecraft.world.phys.AABB;
import net.neoforged.neoforge.event.tick.ServerTickEvent;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.UUID;

/** Stateful gameplay runs entirely on the logical server; no network packets required. */
public final class WitnessManager {
    private static final Map<UUID, WitnessCase> CASES = new HashMap<>();
    private static MinecraftServer currentServer;

    private WitnessManager() { }

    public static void registerCrime(ServerPlayer suspect, BlockPos scene, Entity victim) {
        ServerLevel level = suspect.serverLevel();
        if (suspect.isCreative() || suspect.isSpectator()) return;
        long now = suspect.getServer().overworld().getGameTime();
        if (WantedData.get(suspect.getServer()).isWantedHere(suspect, now)) return;
        if (CASES.containsKey(suspect.getUUID())) return;

        int radius = WitnessConfig.WITNESS_RADIUS.get();
        Villager best = null;
        double bestDistance = Double.POSITIVE_INFINITY;
        AABB area = new AABB(scene).inflate(radius);
        for (Villager villager : level.getEntitiesOfClass(Villager.class, area,
                v -> v.isAlive() && !v.isBaby())) {
            if (villager == victim) continue; // A murdered victim cannot report its own death.
            double distance = villager.distanceToSqr(suspect);
            if (distance > radius * radius) continue;
            // Villagers hear a close assault; at range the culprit must be visible.
            if (distance > 9 * 9 && !villager.getSensing().hasLineOfSight(suspect)) continue;
            if (distance < bestDistance) {
                best = villager;
                bestDistance = distance;
            }
        }
        if (best == null) return;

        BlockPos bell = BellFinder.find(level, best);
        long due = now + WitnessConfig.REPORT_SECONDS.get() * 20L;
        CASES.put(suspect.getUUID(), new WitnessCase(suspect.getUUID(), best.getUUID(),
                level.dimension(), scene.immutable(), bell, now, due, now - 20));
        say(suspect, "message.lastwitness.seen");
        level.sendParticles(ParticleTypes.ANGRY_VILLAGER, best.getX(), best.getY() + 1.8,
                best.getZ(), 4, 0.28, 0.15, 0.28, 0.02);
        level.playSound(null, best.blockPosition(), SoundEvents.VILLAGER_NO,
                SoundSource.NEUTRAL, 0.9f, 1.25f);
    }

    public static boolean isWitnessFor(ServerPlayer player, Villager target) {
        WitnessCase c = CASES.get(player.getUUID());
        return c != null && c.witness().equals(target.getUUID());
    }

    public static void intimidate(ServerPlayer player, Villager witness) {
        if (!isWitnessFor(player, witness)) return;
        ServerLevel level = player.serverLevel();
        if (witness.distanceToSqr(player) > 3.5 * 3.5) return;
        long nearby = level.getEntitiesOfClass(Villager.class, witness.getBoundingBox().inflate(8),
                v -> v != witness && v.isAlive() && !v.isBaby()).size();
        // Threats work when isolated. An audience makes the witness shout immediately.
        if (nearby > 0 || level.getRandom().nextFloat() < 0.3f) {
            WitnessCase c = CASES.remove(player.getUUID());
            if (c != null) report(player.getServer(), c, witness);
            say(player, "message.lastwitness.intimidation_failed");
        } else {
            CASES.remove(player.getUUID());
            witness.getNavigation().stop();
            say(player, "message.lastwitness.silenced");
            level.playSound(null, witness.blockPosition(), SoundEvents.VILLAGER_YES,
                    SoundSource.NEUTRAL, 0.8f, 0.7f);
        }
    }

    public static void tick(ServerTickEvent.Post event) {
        MinecraftServer server = event.getServer();
        if (currentServer != server) {
            CASES.clear(); // Never carry active cases between integrated/dedicated worlds.
            currentServer = server;
        }
        long now = server.overworld().getGameTime();
        if (now % 10L != 0L) return;

        Iterator<Map.Entry<UUID, WitnessCase>> it = CASES.entrySet().iterator();
        while (it.hasNext()) {
            WitnessCase c = it.next().getValue();
            ServerPlayer player = server.getPlayerList().getPlayer(c.suspect());
            ServerLevel level = server.getLevel(c.dimension());
            if (level == null || player == null || !player.isAlive()) {
                it.remove();
                continue;
            }
            Entity entity = level.getEntity(c.witness());
            if (!(entity instanceof Villager witness) || !witness.isAlive()) {
                it.remove();
                say(player, "message.lastwitness.witness_lost");
                continue;
            }
            BlockPos bell = c.bellPos();
            if (bell != null && level.hasChunkAt(bell) && level.getBlockState(bell).is(net.minecraft.world.level.block.Blocks.BELL)) {
                if (witness.distanceToSqr(bell.getX() + 0.5, bell.getY() + 0.5, bell.getZ() + 0.5) <= 9.0) {
                    it.remove();
                    report(server, c, witness);
                    continue;
                }
                if (now - c.lastPathAt() >= 20) {
                    witness.getNavigation().moveTo(bell.getX() + 0.5, bell.getY(),
                            bell.getZ() + 0.5, 1.25D);
                    c = c.withLastPathAt(now);
                    CASES.put(c.suspect(), c);
                }
            }
            if (now >= c.deadline()) {
                it.remove();
                // A witness without access to the bell can still report to nearby villagers.
                if (level.getEntitiesOfClass(Villager.class, witness.getBoundingBox().inflate(9),
                        v -> v != witness && v.isAlive() && !v.isBaby()).isEmpty()) {
                    say(player, "message.lastwitness.no_report");
                } else {
                    report(server, c, witness);
                }
            }
        }

        if (now % 40L == 0L) {
            WantedData data = WantedData.get(server);
            for (ServerPlayer player : server.getPlayerList().getPlayers()) {
                if (!data.isWantedHere(player, now)) continue;
                say(player, "message.lastwitness.wanted");
                for (IronGolem golem : player.serverLevel().getEntitiesOfClass(IronGolem.class,
                        player.getBoundingBox().inflate(24), g -> g.isAlive())) {
                    if (golem.getTarget() == null || golem.getTarget() == player) {
                        golem.setTarget(player);
                    }
                }
            }
        }
        if (now % 200L == 0L) WantedData.get(server).removeExpired(now);
    }

    private static void report(MinecraftServer server, WitnessCase c, Villager witness) {
        ServerPlayer player = server.getPlayerList().getPlayer(c.suspect());
        if (player == null) return;
        ServerLevel level = (ServerLevel) witness.level();
        BlockPos alarm = c.bellPos() != null ? c.bellPos() : witness.blockPosition();
        WantedData.get(server).report(player.getUUID(), level.dimension().location().toString(),
                alarm, server.overworld().getGameTime());
        level.playSound(null, alarm, SoundEvents.BELL_BLOCK, SoundSource.BLOCKS, 1.5f, 1.0f);
        level.sendParticles(ParticleTypes.ANGRY_VILLAGER, witness.getX(),
                witness.getY() + 2, witness.getZ(), 12, 0.4, 0.3, 0.4, 0.03);
        say(player, "message.lastwitness.reported");
    }

    public static boolean wantedHere(ServerPlayer player) {
        return WantedData.get(player.getServer()).isWantedHere(player,
                player.getServer().overworld().getGameTime());
    }

    public static void say(ServerPlayer player, String key) {
        player.displayClientMessage(Component.translatable(key), true);
    }
}

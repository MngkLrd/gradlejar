package dev.minemods.lastwitness;

import dev.minemods.lastwitness.config.WitnessConfig;
import dev.minemods.lastwitness.crime.CrimeEvents;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.fml.ModContainer;
import net.neoforged.fml.common.Mod;
import net.neoforged.fml.config.ModConfig;
import net.neoforged.neoforge.common.NeoForge;

@Mod(LastWitnessMod.MOD_ID)
public final class LastWitnessMod {
    public static final String MOD_ID = "lastwitness";

    public LastWitnessMod(IEventBus modBus, ModContainer container) {
        container.registerConfig(ModConfig.Type.SERVER, WitnessConfig.SPEC);
        NeoForge.EVENT_BUS.register(new CrimeEvents());
    }
}

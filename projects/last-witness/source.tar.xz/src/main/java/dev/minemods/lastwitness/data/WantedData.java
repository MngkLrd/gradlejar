package dev.minemods.lastwitness.data;

import dev.minemods.lastwitness.config.WitnessConfig;
import net.minecraft.core.BlockPos;
import net.minecraft.core.HolderLookup;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.Tag;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.level.saveddata.SavedData;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.UUID;

/** Kept in overworld/data/lastwitness_wanted.dat, shared across all dimensions. */
public final class WantedData extends SavedData {
    public record Wanted(String dimension, BlockPos origin, long until) { }
    private final Map<UUID, Wanted> records = new HashMap<>();

    public static WantedData get(MinecraftServer server) {
        return server.overworld().getDataStorage().computeIfAbsent(
                new SavedData.Factory<>(WantedData::new, WantedData::load), "lastwitness_wanted");
    }

    private static WantedData load(CompoundTag tag, HolderLookup.Provider registry) {
        WantedData data = new WantedData();
        ListTag entries = tag.getList("records", Tag.TAG_COMPOUND);
        for (int i = 0; i < entries.size(); ++i) {
            CompoundTag entry = entries.getCompound(i);
            if (!entry.hasUUID("player")) continue;
            data.records.put(entry.getUUID("player"), new Wanted(
                    entry.getString("dimension"),
                    new BlockPos(entry.getInt("x"), entry.getInt("y"), entry.getInt("z")),
                    entry.getLong("until")));
        }
        return data;
    }

    @Override
    public CompoundTag save(CompoundTag tag, HolderLookup.Provider registry) {
        ListTag entries = new ListTag();
        for (Map.Entry<UUID, Wanted> entry : records.entrySet()) {
            Wanted heat = entry.getValue();
            CompoundTag c = new CompoundTag();
            c.putUUID("player", entry.getKey());
            c.putString("dimension", heat.dimension());
            c.putInt("x", heat.origin().getX());
            c.putInt("y", heat.origin().getY());
            c.putInt("z", heat.origin().getZ());
            c.putLong("until", heat.until());
            entries.add(c);
        }
        tag.put("records", entries);
        return tag;
    }

    public void report(UUID playerId, String dimension, BlockPos position, long now) {
        records.put(playerId, new Wanted(dimension, position.immutable(), now +
                WitnessConfig.WANTED_SECONDS.get() * 20L));
        setDirty();
    }

    public boolean isWantedHere(ServerPlayer player, long now) {
        Wanted wanted = records.get(player.getUUID());
        if (wanted == null || now >= wanted.until()) return false;
        if (!wanted.dimension().equals(player.serverLevel().dimension().location().toString())) return false;
        double radius = WitnessConfig.WANTED_RADIUS.get();
        return wanted.origin().distSqr(player.blockPosition()) <= radius * radius;
    }

    public void removeExpired(long now) {
        boolean changed = false;
        Iterator<Wanted> it = records.values().iterator();
        while (it.hasNext()) {
            if (it.next().until() <= now) {
                it.remove();
                changed = true;
            }
        }
        if (changed) setDirty();
    }
}

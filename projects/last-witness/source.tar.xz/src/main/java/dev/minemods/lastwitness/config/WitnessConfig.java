package dev.minemods.lastwitness.config;

import net.neoforged.neoforge.common.ModConfigSpec;

public final class WitnessConfig {
    public static final ModConfigSpec SPEC;
    public static final ModConfigSpec.IntValue WITNESS_RADIUS;
    public static final ModConfigSpec.IntValue REPORT_SECONDS;
    public static final ModConfigSpec.IntValue WANTED_SECONDS;
    public static final ModConfigSpec.IntValue WANTED_RADIUS;
    public static final ModConfigSpec.BooleanValue INTIMIDATION;
    public static final ModConfigSpec.BooleanValue BELL_VANDALISM;

    static {
        ModConfigSpec.Builder b = new ModConfigSpec.Builder();
        b.push("witnesses");
        WITNESS_RADIUS = b.comment("How far a villager can notice an assault or a broken bell, in blocks.")
                .defineInRange("noticeRadius", 20, 6, 48);
        REPORT_SECONDS = b.comment("Maximum time before a witness can spread the news without a bell.")
                .defineInRange("reportSeconds", 10, 3, 45);
        INTIMIDATION = b.comment("Sneak + right-click the witness with a sword or axe to try to silence them.")
                .define("enableIntimidation", true);
        BELL_VANDALISM = b.comment("Breaking a village bell in front of a witness counts as a crime.")
                .define("bellVandalism", true);
        b.pop();
        b.push("wanted");
        WANTED_SECONDS = b.comment("How long a reported crime is remembered, in seconds.")
                .defineInRange("wantedSeconds", 240, 30, 3600);
        WANTED_RADIUS = b.comment("Radius around the reported village alarm in which golems and traders react.")
                .defineInRange("wantedRadius", 48, 16, 128);
        b.pop();
        SPEC = b.build();
    }

    private WitnessConfig() {}
}

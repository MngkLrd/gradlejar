package dev.minemods.bigfrogs;

import dev.minemods.bigfrogs.registry.ModEntities;
import dev.minemods.bigfrogs.registry.ModItems;
import dev.minemods.bigfrogs.registry.ModMobEvents;
import net.minecraft.world.item.CreativeModeTabs;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.fml.common.Mod;
import net.neoforged.neoforge.event.BuildCreativeModeTabContentsEvent;

@Mod(BigFrogs.MOD_ID)
public final class BigFrogs {
    public static final String MOD_ID = "bigfrogs";

    public BigFrogs(IEventBus modBus) {
        ModEntities.ENTITIES.register(modBus);
        ModItems.ITEMS.register(modBus);
        modBus.addListener(ModMobEvents::registerAttributes);
        modBus.addListener(ModMobEvents::registerSpawnPlacements);
        modBus.addListener(BigFrogs::addCreativeItems);
    }

    private static void addCreativeItems(BuildCreativeModeTabContentsEvent event) {
        if (event.getTabKey() == CreativeModeTabs.SPAWN_EGGS) {
            event.accept(ModItems.BIG_FROG_SPAWN_EGG.get());
        }
        if (event.getTabKey() == CreativeModeTabs.INGREDIENTS) {
            event.accept(ModItems.FROG_SKIN.get());
        }
        if (event.getTabKey() == CreativeModeTabs.FOOD_AND_DRINKS) {
            event.accept(ModItems.BIG_FROG_LEG.get());
            event.accept(ModItems.COOKED_BIG_FROG_LEG.get());
        }
    }
}

package dev.minemods.bigfrogs.registry;

import dev.minemods.bigfrogs.BigFrogs;
import net.minecraft.world.food.FoodProperties;
import net.minecraft.world.item.Item;
import net.neoforged.neoforge.common.DeferredSpawnEggItem;
import net.neoforged.neoforge.registries.DeferredItem;
import net.neoforged.neoforge.registries.DeferredRegister;

public final class ModItems {
    private ModItems() {}

    public static final DeferredRegister.Items ITEMS = DeferredRegister.createItems(BigFrogs.MOD_ID);

    public static final DeferredItem<Item> BIG_FROG_LEG = ITEMS.registerSimpleItem("big_frog_leg",
            new Item.Properties().food(new FoodProperties.Builder()
                    .nutrition(3).saturationModifier(0.3f).build()));

    public static final DeferredItem<Item> COOKED_BIG_FROG_LEG = ITEMS.registerSimpleItem("cooked_big_frog_leg",
            new Item.Properties().food(new FoodProperties.Builder()
                    .nutrition(6).saturationModifier(0.6f).build()));

    public static final DeferredItem<Item> FROG_SKIN = ITEMS.registerSimpleItem("frog_skin",
            new Item.Properties());

    public static final DeferredItem<DeferredSpawnEggItem> BIG_FROG_SPAWN_EGG = ITEMS.registerItem(
            "big_frog_spawn_egg",
            properties -> new DeferredSpawnEggItem(ModEntities.BIG_FROG, 0x5B5A32, 0xA89A65, properties));
}

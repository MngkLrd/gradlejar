package dev.minemods.bigfrogs.client;

import com.mojang.blaze3d.vertex.PoseStack;
import dev.minemods.bigfrogs.BigFrogs;
import dev.minemods.bigfrogs.entity.BigFrogEntity;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.resources.ResourceLocation;

public final class BigFrogRenderer extends MobRenderer<BigFrogEntity, BigFrogModel> {
    private static final ResourceLocation[] SKINS = {
            ResourceLocation.fromNamespaceAndPath(BigFrogs.MOD_ID, "textures/entity/big_frog_olive.png"),
            ResourceLocation.fromNamespaceAndPath(BigFrogs.MOD_ID, "textures/entity/big_frog_brown.png"),
            ResourceLocation.fromNamespaceAndPath(BigFrogs.MOD_ID, "textures/entity/big_frog_moss.png")
    };

    public BigFrogRenderer(EntityRendererProvider.Context context) {
        super(context, new BigFrogModel(context.bakeLayer(BigFrogModel.LAYER)), 0.8f);
    }

    @Override
    public ResourceLocation getTextureLocation(BigFrogEntity entity) {
        return SKINS[Math.floorMod(entity.getSkinVariant(), SKINS.length)];
    }

    @Override
    protected void scale(BigFrogEntity entity, PoseStack stack, float partialTick) {
        if (entity.isChunky()) {
            stack.scale(1.35f, 1.28f, 1.32f);
        } else {
            stack.scale(1.18f, 1.18f, 1.20f);
        }
    }
}

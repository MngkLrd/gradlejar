package dev.minemods.bigfrogs.client;

import dev.minemods.bigfrogs.BigFrogs;
import dev.minemods.bigfrogs.entity.BigFrogEntity;
import net.minecraft.client.model.HierarchicalModel;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeDeformation;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;

/** Original cuboid toad with broad head, round belly, short legs and a retractable tongue. */
public final class BigFrogModel extends HierarchicalModel<BigFrogEntity> {
    public static final ModelLayerLocation LAYER = new ModelLayerLocation(
            ResourceLocation.fromNamespaceAndPath(BigFrogs.MOD_ID, "big_frog"), "main");

    private final ModelPart root;
    private final ModelPart body;
    private final ModelPart head;
    private final ModelPart leftFront;
    private final ModelPart rightFront;
    private final ModelPart leftHind;
    private final ModelPart rightHind;
    private final ModelPart tongue;

    public BigFrogModel(ModelPart root) {
        this.root = root;
        this.body = root.getChild("body");
        this.head = root.getChild("head");
        this.leftFront = root.getChild("left_front");
        this.rightFront = root.getChild("right_front");
        this.leftHind = root.getChild("left_hind");
        this.rightHind = root.getChild("right_hind");
        this.tongue = head.getChild("tongue");
    }

    public static LayerDefinition createLayer() {
        MeshDefinition mesh = new MeshDefinition();
        PartDefinition root = mesh.getRoot();
        // Model-space feet at Y=24, with a broad low body and substantial hindquarters.
        root.addOrReplaceChild("body", CubeListBuilder.create()
                .texOffs(0, 0).addBox(-8.0f, -8.0f, -10.0f, 16, 11, 19),
                PartPose.offset(0, 15, 2));
        PartDefinition head = root.addOrReplaceChild("head", CubeListBuilder.create()
                .texOffs(0, 32).addBox(-7.0f, -6.0f, -9.0f, 14, 8, 10)
                .texOffs(52, 32).addBox(-7.0f, -8.0f, -8.0f, 5, 3, 4)
                .texOffs(52, 32).addBox(2.0f, -8.0f, -8.0f, 5, 3, 4),
                PartPose.offset(0, 12, -9));
        head.addOrReplaceChild("tongue", CubeListBuilder.create()
                .texOffs(0, 56).addBox(-1.0f, 0.0f, -24.0f, 2, 1, 24),
                PartPose.offset(0, 0, -8));
        root.addOrReplaceChild("left_front", CubeListBuilder.create()
                .texOffs(72, 0).addBox(0.0f, 0.0f, -2.5f, 4, 7, 5),
                PartPose.offset(7, 17, -7));
        root.addOrReplaceChild("right_front", CubeListBuilder.create()
                .texOffs(72, 0).mirror().addBox(-4.0f, 0.0f, -2.5f, 4, 7, 5).mirror(false),
                PartPose.offset(-7, 17, -7));
        root.addOrReplaceChild("left_hind", CubeListBuilder.create()
                .texOffs(72, 16).addBox(0.0f, -3.0f, -3.0f, 6, 8, 8),
                PartPose.offset(7, 18, 7));
        root.addOrReplaceChild("right_hind", CubeListBuilder.create()
                .texOffs(72, 16).mirror().addBox(-6.0f, -3.0f, -3.0f, 6, 8, 8).mirror(false),
                PartPose.offset(-7, 18, 7));
        return LayerDefinition.create(mesh, 128, 96);
    }

    @Override
    public ModelPart root() { return root; }

    @Override
    public void setupAnim(BigFrogEntity entity, float limbSwing, float limbSwingAmount,
                          float ageInTicks, float netHeadYaw, float headPitch) {
        root.getAllParts().forEach(ModelPart::resetPose);
        float stride = Mth.cos(limbSwing * 0.8f) * Math.min(limbSwingAmount, 1.0f) * 0.5f;
        leftFront.xRot = stride;
        rightFront.xRot = -stride;
        leftHind.xRot = -stride * 0.75f;
        rightHind.xRot = stride * 0.75f;
        head.yRot = netHeadYaw * Mth.DEG_TO_RAD * 0.22f;
        head.xRot = headPitch * Mth.DEG_TO_RAD * 0.13f;
        // A third of the population has a visibly wider belly, not just a scaled-up frog.
        if (entity.isChunky()) {
            body.xScale = 1.27f;
            body.yScale = 1.17f;
            body.zScale = 1.16f;
        }
        int ticks = entity.getTongueTicks();
        tongue.visible = ticks > 0;
        if (ticks > 0) {
            float extension = ticks > 9 ? (12.0f - ticks) / 3.0f
                    : ticks < 4 ? ticks / 4.0f : 1.0f;
            tongue.zScale = Math.max(0.05f, extension);
        }
    }
}

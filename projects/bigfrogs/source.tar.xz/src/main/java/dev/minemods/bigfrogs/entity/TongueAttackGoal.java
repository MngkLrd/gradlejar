package dev.minemods.bigfrogs.entity;

import java.util.EnumSet;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.goal.Goal;
import org.jetbrains.annotations.Nullable;

/** Server-side navigation and ranged melee tongue attack. */
final class TongueAttackGoal extends Goal {
    private final BigFrogEntity frog;
    @Nullable private LivingEntity prey;

    TongueAttackGoal(BigFrogEntity frog) {
        this.frog = frog;
        setFlags(EnumSet.of(Flag.MOVE, Flag.LOOK));
    }

    @Override
    public boolean canUse() {
        prey = frog.findPrey();
        return prey != null;
    }

    @Override
    public boolean canContinueToUse() {
        return prey != null && prey.isAlive() && frog.distanceToSqr(prey) < 196.0;
    }

    @Override
    public void tick() {
        if (prey == null) return;
        frog.getLookControl().setLookAt(prey, 30.0f, 30.0f);
        if (frog.distanceToSqr(prey) > 11.0) {
            frog.getNavigation().moveTo(prey, 1.10);
        } else {
            frog.getNavigation().stop();
        }
        if (frog.canTongueAttack(prey)) frog.lashAt(prey);
    }

    @Override
    public void stop() {
        prey = null;
        frog.getNavigation().stop();
    }
}

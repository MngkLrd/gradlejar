package dev.minemods.bigfrogs.registry;

import dev.minemods.bigfrogs.BigFrogs;
import dev.minemods.bigfrogs.entity.BigFrogEntity;
import net.minecraft.core.registries.Registries;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobCategory;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.registries.DeferredRegister;

public final class ModEntities {
    private ModEntities() {}

    public static final DeferredRegister<EntityType<?>> ENTITIES =
            DeferredRegister.create(Registries.ENTITY_TYPE, BigFrogs.MOD_ID);

    public static final DeferredHolder<EntityType<?>, EntityType<BigFrogEntity>> BIG_FROG =
            ENTITIES.register("big_frog", () -> EntityType.Builder.of(BigFrogEntity::new, MobCategory.CREATURE)
                    .sized(1.45f, 1.15f)
                    .clientTrackingRange(10)
                    .build("bigfrogs:big_frog"));
}

package dev.minemods.bigfrogs.entity;

import dev.minemods.bigfrogs.registry.ModEntities;
import net.minecraft.core.BlockPos;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.tags.BlockTags;
import net.minecraft.util.RandomSource;
import net.minecraft.world.DifficultyInstance;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.AgeableMob;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.MobSpawnType;
import net.minecraft.world.entity.SpawnGroupData;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.BreedGoal;
import net.minecraft.world.entity.ai.goal.FloatGoal;
import net.minecraft.world.entity.ai.goal.LookAtPlayerGoal;
import net.minecraft.world.entity.ai.goal.RandomLookAroundGoal;
import net.minecraft.world.entity.ai.goal.RandomStrollGoal;
import net.minecraft.world.entity.ai.goal.TemptGoal;
import net.minecraft.world.entity.ai.goal.target.HurtByTargetGoal;
import net.minecraft.world.entity.animal.Animal;
import net.minecraft.world.entity.monster.Slime;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.crafting.Ingredient;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.level.ServerLevelAccessor;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import org.jetbrains.annotations.Nullable;

/** A peaceful giant toad until attacked. It lashes out at small slimes and aggressors. */
public class BigFrogEntity extends Animal {
    private static final EntityDataAccessor<Integer> SKIN_VARIANT =
            SynchedEntityData.defineId(BigFrogEntity.class, EntityDataSerializers.INT);
    private static final EntityDataAccessor<Boolean> CHUNKY =
            SynchedEntityData.defineId(BigFrogEntity.class, EntityDataSerializers.BOOLEAN);
    private static final EntityDataAccessor<Integer> TONGUE_TICKS =
            SynchedEntityData.defineId(BigFrogEntity.class, EntityDataSerializers.INT);

    private int attackCooldown;
    @Nullable private LivingEntity tongueVictim;

    public BigFrogEntity(EntityType<? extends Animal> type, Level level) {
        super(type, level);
        this.xpReward = 3;
    }

    @Override
    protected void defineSynchedData(SynchedEntityData.Builder builder) {
        super.defineSynchedData(builder);
        builder.define(SKIN_VARIANT, 0);
        builder.define(CHUNKY, false);
        builder.define(TONGUE_TICKS, 0);
    }

    @Override
    protected void registerGoals() {
        goalSelector.addGoal(0, new FloatGoal(this));
        goalSelector.addGoal(1, new TongueAttackGoal(this));
        goalSelector.addGoal(3, new BreedGoal(this, 0.9));
        goalSelector.addGoal(4, new TemptGoal(this, 1.05, Ingredient.of(Items.SLIME_BALL), false));
        goalSelector.addGoal(5, new RandomStrollGoal(this, 0.75));
        goalSelector.addGoal(6, new LookAtPlayerGoal(this, Player.class, 7.0f));
        goalSelector.addGoal(7, new RandomLookAroundGoal(this));
        targetSelector.addGoal(1, new HurtByTargetGoal(this));
    }

    public static AttributeSupplier.Builder createAttributes() {
        return net.minecraft.world.entity.Mob.createMobAttributes()
                .add(Attributes.MAX_HEALTH, 18.0)
                .add(Attributes.MOVEMENT_SPEED, 0.20)
                .add(Attributes.ATTACK_DAMAGE, 3.0)
                .add(Attributes.FOLLOW_RANGE, 15.0);
    }

    public static boolean canSpawn(EntityType<BigFrogEntity> type, LevelAccessor level,
                                   MobSpawnType reason, BlockPos pos, RandomSource random) {
        return level.getBlockState(pos.below()).is(BlockTags.FROGS_SPAWNABLE_ON)
                && level.getRawBrightness(pos, 0) > 8
                && level.getBlockState(pos).getFluidState().isEmpty();
    }

    @Override
    public SpawnGroupData finalizeSpawn(ServerLevelAccessor level, DifficultyInstance difficulty,
                                         MobSpawnType reason, @Nullable SpawnGroupData group) {
        SpawnGroupData data = super.finalizeSpawn(level, difficulty, reason, group);
        entityData.set(SKIN_VARIANT, random.nextInt(3));
        entityData.set(CHUNKY, random.nextInt(100) < 35);
        return data;
    }

    public int getSkinVariant() { return entityData.get(SKIN_VARIANT); }
    public boolean isChunky() { return entityData.get(CHUNKY); }
    public int getTongueTicks() { return entityData.get(TONGUE_TICKS); }

    public boolean canTongueAttack(LivingEntity target) {
        return attackCooldown == 0 && getTongueTicks() == 0 && target.isAlive()
                && this.distanceToSqr(target) <= 16.0 && this.getSensing().hasLineOfSight(target);
    }

    public void lashAt(LivingEntity target) {
        if (level().isClientSide || !canTongueAttack(target)) return;
        tongueVictim = target;
        attackCooldown = 40;
        entityData.set(TONGUE_TICKS, 12);
        this.getLookControl().setLookAt(target, 30.0f, 30.0f);
        playSound(SoundEvents.FROG_TONGUE, 0.95f, 0.75f + random.nextFloat() * 0.2f);
    }

    @Override
    public void tick() {
        super.tick();
        if (!level().isClientSide) {
            if (attackCooldown > 0) attackCooldown--;
            int remaining = getTongueTicks();
            if (remaining > 0) {
                entityData.set(TONGUE_TICKS, remaining - 1);
                if (remaining == 7 && tongueVictim != null && tongueVictim.isAlive()
                        && this.distanceToSqr(tongueVictim) <= 20.25
                        && this.getSensing().hasLineOfSight(tongueVictim)) {
                    tongueVictim.hurt(this.damageSources().mobAttack(this), isChunky() ? 4.0f : 3.0f);
                    // Pull targets a little, as a physical tongue strike rather than a bite.
                    double dx = getX() - tongueVictim.getX();
                    double dz = getZ() - tongueVictim.getZ();
                    double len = Math.max(1.0, Math.sqrt(dx * dx + dz * dz));
                    tongueVictim.push(dx / len * 0.22, 0.08, dz / len * 0.22);
                }
                if (remaining == 1) tongueVictim = null;
            }
        }
    }

    @Override
    public boolean isFood(ItemStack stack) { return stack.is(Items.SLIME_BALL); }

    @Nullable
    @Override
    public AgeableMob getBreedOffspring(ServerLevel level, AgeableMob parent) {
        BigFrogEntity child = ModEntities.BIG_FROG.get().create(level);
        if (child != null) {
            child.entityData.set(SKIN_VARIANT, random.nextInt(3));
            child.entityData.set(CHUNKY, random.nextInt(100) < 35);
        }
        return child;
    }

    @Override
    public void addAdditionalSaveData(CompoundTag tag) {
        super.addAdditionalSaveData(tag);
        tag.putInt("SkinVariant", getSkinVariant());
        tag.putBoolean("Chunky", isChunky());
    }

    @Override
    public void readAdditionalSaveData(CompoundTag tag) {
        super.readAdditionalSaveData(tag);
        if (tag.contains("SkinVariant")) entityData.set(SKIN_VARIANT, Math.floorMod(tag.getInt("SkinVariant"), 3));
        if (tag.contains("Chunky")) entityData.set(CHUNKY, tag.getBoolean("Chunky"));
    }

    @Nullable
    @Override
    protected SoundEvent getAmbientSound() { return SoundEvents.FROG_AMBIENT; }

    @Override
    protected SoundEvent getHurtSound(DamageSource source) { return SoundEvents.FROG_HURT; }

    @Override
    protected SoundEvent getDeathSound() { return SoundEvents.FROG_DEATH; }

    public @Nullable LivingEntity findPrey() {
        LivingEntity attacker = getTarget();
        if (attacker != null && attacker.isAlive() && !attacker.isSpectator()) return attacker;
        if (tickCount % 20 != 0) return null;
        var slimes = level().getEntitiesOfClass(Slime.class, getBoundingBox().inflate(7.0),
                slime -> slime.isAlive() && slime.getSize() <= 2);
        if (slimes.isEmpty()) return null;
        return slimes.getFirst();
    }
}

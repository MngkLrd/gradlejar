package dev.minemods.bigfrogs.registry;

import dev.minemods.bigfrogs.entity.BigFrogEntity;
import net.minecraft.world.entity.SpawnPlacementTypes;
import net.minecraft.world.level.levelgen.Heightmap;
import net.neoforged.neoforge.event.entity.EntityAttributeCreationEvent;
import net.neoforged.neoforge.event.entity.RegisterSpawnPlacementsEvent;

public final class ModMobEvents {
    private ModMobEvents() {}

    public static void registerAttributes(EntityAttributeCreationEvent event) {
        event.put(ModEntities.BIG_FROG.get(), BigFrogEntity.createAttributes().build());
    }

    public static void registerSpawnPlacements(RegisterSpawnPlacementsEvent event) {
        event.register(ModEntities.BIG_FROG.get(),
                SpawnPlacementTypes.ON_GROUND,
                Heightmap.Types.MOTION_BLOCKING_NO_LEAVES,
                BigFrogEntity::canSpawn,
                RegisterSpawnPlacementsEvent.Operation.REPLACE);
    }
}

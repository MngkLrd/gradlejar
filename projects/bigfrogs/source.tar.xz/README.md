# Big Frogs 0.1.1
Minecraft 1.21.1 / NeoForge 21.1.202 / Java 21.

Adds an oversized amphibian native to mangrove swamps. About 35% are visibly chubbier, with three original swamp-toned skins. Toads are generally peaceful, but retaliate when hit; they also hunt small slimes using a visible extending tongue (3-4 block strike range). Breeding uses slimeballs. Vanilla cows/frogs are not changed.

## Drops
* Raw Big Frog Leg: 1–2 pieces on death, edible raw (3 hunger points, saturation modifier 0.3). Cook into Cooked Big Frog Leg (6 nutrition, saturation modifier 0.6) in a furnace, smoker or campfire.
* Frog Skin: 0–2 pieces on death. Included in common `c:leathers` tag and converts 1:1 into ordinary Leather at a crafting table (so vanilla leather-only recipes remain usable without replacing vanilla recipes).

## Item art: Blockbench Minecraft Style Guide
The three hand-authored 16×16 PNGs (`frog_skin`, `big_frog_leg`, `cooked_big_frog_leg`) use no Minecraft-sourced pixel assets. Design follows only the official [Blockbench Minecraft Style Guide](https://blockbench.net/wiki/guides/minecraft-style-guide/), specifically the Item Textures / Color Ramps / Shading / Lines & Shapes chapters. Each uses a clear midtone silhouette, one-pixel dark contour, northwest lighting, connected shade clusters, material-specific marks, and restrained hue-shifted colors. No blur, antialiasing, dithering, gradients, random speckles or mixed-resolution details.

Generate item textures with `python3 generate_item_textures.py` (requires Pillow), or run `python3 generate_textures.py` to also update the existing entity atlas. The pre-generated PNGs are committed to `src/main/resources/assets/bigfrogs/textures/item/`; Python is NOT required to build the mod.

## Build
Requires Java 21 and Gradle 9.2.1 (local Gradle or GitHub Actions). Run `gradle --no-daemon clean build` at project root. Final JAR: `build/libs/bigfrogs-neoforge-1.21.1-0.1.1.jar`. Copy the JAR to `.minecraft/mods` with NeoForge 1.21.1.

## Test
1. Start client and dedicated server to detect client-only class loading bugs.
2. `/summon bigfrogs:big_frog` and inspect size, shape, textures, walking, tongue.
3. Spawn 20 frogs, check that some are chunkier and all three textures occur.
4. Spawn small slimes nearby and observe tongue attack; hit frog in Survival, observe retaliation.
5. `/locate biome minecraft:mangrove_swamp`, wait for natural spawn; ensure no other biome spawns.
6. Kill frog, check drops, cook/craft in test world; craft Frog Skin into vanilla Leather.
7. Reload world and verify texture/body variants persist.

## Known limitations
* Large frogs do not lay frogspawn/tadpoles. Breeding makes another Big Frog directly.
* This is an MVP and has not been playtested in a live client in this environment; Java compile via GitHub CI is required before claiming build success.

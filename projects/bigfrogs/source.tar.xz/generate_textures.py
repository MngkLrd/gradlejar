"""Build original, deterministic, vanilla-inspired 128x96 animal and 16x16 item pixels.
No Minecraft original textures are used. Each patch is a coherent pixel cluster.
"""
from PIL import Image, ImageDraw
from random import Random
from pathlib import Path
out=Path(__file__).parent/'src/main/resources/assets/bigfrogs/textures'

def rgb(h): return tuple(bytes.fromhex(h))

def atlas(name, palette, seed):
    r=Random(seed)
    im=Image.new('RGBA',(128,96),(0,0,0,0)); p=im.load()
    def fill(rect, base):
        x0,y0,x1,y1=rect
        for y in range(y0,y1):
            for x in range(x0,x1):
                p[x,y]=rgb(palette[base])+(255,)
        # Connected 2-6 px patches rather than pixel-level noise.
        for k in range(max(1, (x1-x0)*(y1-y0)//34)):
            x=r.randrange(x0,x1); y=r.randrange(y0,y1)
            col=rgb(palette[r.choice(['light','light','dark','mid','mid'])])+(255,)
            w=r.choice([2,2,3,4]); h=r.choice([1,2,2,3])
            for yy in range(y,min(y+h,y1)):
                for xx in range(x,min(x+w,x1)):
                    if (xx-x)+(yy-y)<=w+h-3 or r.random()>.6: p[xx,yy]=col
    fill((0,0,70,30),'mid') # torso and back
    fill((0,32,48,50),'mid') # head
    fill((52,32,70,40),'light') # eye ridges
    fill((72,0,90,12),'mid')
    fill((72,16,100,32),'mid')
    # The side face of the head and torso contains a light, plump under-jaw.
    d=ImageDraw.Draw(im)
    for x in range(10,38):
        for y in range(42,49):
            if x>10+abs(24-x)*0.2 and x<38-abs(24-x)*0.2:
                if r.random() > .20: p[x,y]=rgb(palette['belly'])+(255,)
    for x in range(18,50):
        for y in range(21,28):
            if r.random()>.22: p[x,y]=rgb(palette['belly'])+(255,)
    # Small intentional warts (dark border + lighter center) on upper back.
    for i in range(13):
        x=r.randrange(15,55); y=r.randrange(2,18)
        d.rectangle((x,y,x+3,y+2), fill=rgb(palette['dark'])+(255,))
        d.rectangle((x+1,y,x+2,y), fill=rgb(palette['light'])+(255,))
    # Eye band: a yellowish rim, deep dark pupil, one muted glint.
    for x in (53,62):
        d.rectangle((x,33,x+5,38), fill=rgb(palette['eye'])+(255,))
        d.rectangle((x+1,34,x+4,37), fill=rgb('282C22')+(255,))
        d.point((x+2,34),fill=rgb('90977D')+(255,))
    # Pixelized tongue with coherent color across long UV strip.
    d.rectangle((0,56,51,80),fill=rgb('BD686B')+(255,))
    d.rectangle((3,58,48,62),fill=rgb('CF8281')+(255,))
    d.rectangle((3,72,49,74),fill=rgb('A8585D')+(255,))
    d.rectangle((3,76,8,79),fill=rgb('94494D')+(255,))
    im.save(out/'entity'/f'big_frog_{name}.png')

palettes={
 'olive':dict(mid='747348',dark='535537',light='909067',belly='AE9E74',eye='AAA064'),
 'brown':dict(mid='846141',dark='60462F',light='A67A55',belly='C3A47D',eye='B6A06B'),
 'moss':dict(mid='596C45',dark='3F5034',light='74895C',belly='9EA87B',eye='ABB579')
}
for i,(name,pal) in enumerate(palettes.items()):atlas(name,pal,i*101+7)

# The item atlas is defined in a separate pixel-precise, editable source file.
from generate_item_textures import generate as generate_items
generate_items(out/'item')
print('texture generation complete')

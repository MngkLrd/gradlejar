"""Big Frogs item textures (16x16 RGBA), following only Blockbench's Minecraft Style Guide.

Art process: midtone silhouette -> deliberate dark outline -> top-left highlights and
form-following shadows -> coherent local material clusters. No noise, gradients,
anti-aliasing, checker dithering or resampling. Rerunning is deterministic.
"""
from pathlib import Path
from PIL import Image, ImageDraw

SIZE = 16
TRANSPARENT = (0, 0, 0, 0)

def c(value):
    return tuple(bytes.fromhex(value.lstrip('#'))) + (255,)

def skin():
    # Spread, irregular hide with four soft flaps (not a leaf outline).
    silhouette = [
      '....XX....XX....',
      '...XXXX..XXXX...',
      '..XXXXXXXXXXXX..',
      '.XXXXXXXXXXXXXX.',
      'XXXXXXXXXXXXXXXX',
      'XXXXXXXXXXXXXXXX',
      '.XXXXXXXXXXXXXX.',
      '..XXXXXXXXXXXX..',
      '..XXXXXXXXXXXX..',
      '.XXXXXXXXXXXXXX.',
      'XXXXXXXXXXXXXXXX',
      '.XXXXXXXXXXXXXX.',
      '..XXXXXXXXXXXX..',
      '...XXXXX.XXXXX..',
      '...XXXX...XXX...',
      '....XX......XX..'
    ]
    assert all(len(row) == SIZE for row in silhouette)
    mask = Image.new('L', (SIZE, SIZE), 0)
    pm = mask.load()
    for y, row in enumerate(silhouette):
        for x, char in enumerate(row):
            if char == 'X': pm[x, y] = 255
    im = Image.new('RGBA', (SIZE, SIZE), TRANSPARENT)
    p = im.load()
    # 1px outline, top-left brighter than bottom-right, as recommended for items.
    P = dict(out='2D3B2C', outlit='455637', base='78875B', shadow='5B7049',
             shade2='485C3D', light='97A478', lit2='B1AF82', wart='4B5D3C',
             fold='68734F', membrane='A99A78', membraneDark='82795A')
    for y in range(SIZE):
        for x in range(SIZE):
            if not pm[x, y]: continue
            boundary = any(not (0 <= x+dx < SIZE and 0 <= y+dy < SIZE)
                           or not pm[x+dx, y+dy]
                           for dx, dy in ((1,0),(-1,0),(0,1),(0,-1)))
            if boundary:
                col = P['outlit'] if y < 6 and x < 8 else P['out']
            elif y < 6 and x < 9: col = P['light']
            elif x >= 10 or y >= 10: col = P['shadow']
            else: col = P['base']
            p[x, y] = c(col)
    def clusters(coords, color):
        for x, y in coords:
            if 0 <= x < SIZE and 0 <= y < SIZE and pm[x,y] and p[x,y] not in (c(P['out']),c(P['outlit'])):
                p[x,y] = c(color)
    # Connected local clusters, shaped like folds and rough amphibian hide.
    clusters([(4,3),(5,3),(6,3),(4,4),(5,4),(6,4),(5,5),(6,5)], P['lit2'])
    clusters([(7,5),(8,5),(9,5),(7,6),(8,6)], P['light'])
    clusters([(11,4),(12,4),(12,5),(13,5),(12,6)], P['shadow'])
    clusters([(3,8),(4,8),(5,8),(4,9),(5,9),(6,9)], P['light'])
    clusters([(9,10),(10,10),(11,10),(9,11),(10,11)], P['shade2'])
    clusters([(6,11),(7,11),(6,12)], P['fold'])
    # A narrow light exposed underside at a fold; broken up, not an all-around border.
    clusters([(4,11),(5,12),(5,13),(6,13)], P['membrane'])
    clusters([(12,10),(12,11),(11,12)], P['membraneDark'])
    # Deliberately grouped small raised warts. No uniformly-distributed noise.
    clusters([(10,3),(11,3),(10,4),(11,4),(10,5)], P['wart'])
    clusters([(10,3)], P['light'])
    clusters([(6,8),(7,8),(7,9)], P['wart'])
    clusters([(6,8)], P['lit2'])
    clusters([(3,6),(4,6)], P['fold'])
    return im


def leg(cooked=False):
    im = Image.new('RGBA', (SIZE,SIZE), TRANSPARENT)
    mask = Image.new('L', (SIZE,SIZE), 0)
    m = ImageDraw.Draw(mask)
    # Oversized thigh, slender curved shin, three splayed amphibian toes.
    m.polygon([(7,2),(9,1),(12,2),(14,4),(14,6),(12,8),(10,9),(8,9),(6,7),(5,5)], fill=255)
    m.polygon([(8,8),(10,9),(8,11),(6,12),(5,14),(3,14),(3,12),(5,10),(6,9)],fill=255)
    m.polygon([(4,12),(2,13),(1,15),(3,15),(5,13)], fill=255)
    m.polygon([(5,12),(5,14),(6,15),(8,15),(7,13)],fill=255)
    m.polygon([(6,11),(8,12),(10,14),(10,15),(9,15),(7,14)],fill=255)
    p=im.load(); pm=mask.load()
    if not cooked:
        P = dict(out='333C2F', outlit='526044', base='7B865A', light='A2A979',
                 shade='596949', shade2='455642', glint='BDC09B',
                 flesh='B96E68', fleshLight='DA9791', fleshDark='895451', toes='6D8053')
    else:
        P = dict(out='593C29', outlit='795034', base='B57B40', light='D9A65B',
                 shade='91582F', shade2='73462B', glint='EDC17D',
                 flesh='C98956', fleshLight='E4AE73', fleshDark='965534', toes='AC6D39')
    # Midtone + face-aware top-left light and lower-right shadow.
    for y in range(SIZE):
        for x in range(SIZE):
            if not pm[x,y]: continue
            edge = any(not (0 <= x+dx < SIZE and 0 <= y+dy < SIZE)
                    or not pm[x+dx,y+dy] for dx,dy in ((1,0),(-1,0),(0,1),(0,-1)))
            if edge: key = 'outlit' if x <= 9 and y <= 5 else 'out'
            elif x >= 12 or y >= 10: key = 'shade'
            elif x <= 10 and y <= 5: key='light'
            else: key='base'
            p[x,y]=c(P[key])
    outline = (c(P['out']),c(P['outlit']))
    def add(coords, key):
        color=c(P[key])
        for x,y in coords:
            if 0<=x<16 and 0<=y<16 and pm[x,y] and p[x,y] not in outline:
                p[x,y]=color
    # Fat thigh highlights follow anatomy rather than evenly covering an edge.
    add([(8,3),(9,3),(10,3),(8,4),(9,4),(10,4),(8,5)],'glint')
    add([(11,3),(12,4),(11,4),(10,5)],'light')
    add([(11,7),(12,6),(11,8),(10,8)],'shade')
    add([(7,8),(8,9),(7,9),(6,10)], 'shade2')
    add([(5,11),(6,11),(5,12),(4,13)],'light')
    add([(4,12),(3,13),(5,13)],'toes')
    # Raw red/pink exposed meat on the haunch; roasted fibrous crust for cooked.
    add([(8,6),(9,6),(10,6),(9,7),(10,7)], 'flesh')
    add([(8,6),(9,6)], 'fleshLight')
    add([(10,7),(11,6)], 'fleshDark')
    if cooked:
        # Purposeful, sparse caramelized clusters rather than a noisy brown overlay.
        add([(12,5),(12,6),(11,7)],'shade2')
        add([(9,4),(10,4)],'glint')
        add([(6,12),(6,13)],'flesh')
    else:
        # Desaturated webbed membrane on toes.
        add([(3,14),(4,14),(5,14)],'toes')
    return im


def generate(directory):
    directory = Path(directory)
    directory.mkdir(parents=True, exist_ok=True)
    for name, im in (
        ('frog_skin', skin()),
        ('big_frog_leg', leg(False)),
        ('cooked_big_frog_leg', leg(True))
    ):
        assert im.size == (SIZE, SIZE)
        assert max(im.getchannel('A').getextrema()) == 255
        assert set(im.getchannel('A').get_flattened_data()) <= {0,255}, 'no semitransparent pixels'
        im.save(directory / f'{name}.png', optimize=True)
    return directory

if __name__ == '__main__':
    target = Path(__file__).parent/'src/main/resources/assets/bigfrogs/textures/item'
    generate(target)
    print('Created:',*[f'{p.name} ({p.stat().st_size} bytes)' for p in sorted(target.glob('*.png'))])

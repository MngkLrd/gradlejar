package com.kirill.simplesorter.client;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.screens.Screen;

import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;

public final class ClientScreenAccess {
    private ClientScreenAccess() {}

    public static boolean hasScreen(Minecraft minecraft) {
        return getCurrentScreen(minecraft) != null;
    }

    public static Screen getCurrentScreen(Minecraft minecraft) {
        Screen byMethod = getScreenByMethod(minecraft);
        if (byMethod != null) {
            return byMethod;
        }
        return getScreenByField(minecraft);
    }

    public static void openScreen(Minecraft minecraft, Screen screen) {
        if (trySetScreenByMethod(minecraft, screen)) {
            return;
        }
        if (trySetScreenByField(minecraft, screen)) {
            return;
        }
        throw new IllegalStateException("Could not open Simple Sorter screen on this Minecraft/NeoForge build");
    }

    private static Screen getScreenByMethod(Minecraft minecraft) {
        for (Method method : Minecraft.class.getDeclaredMethods()) {
            if (method.getParameterCount() != 0) {
                continue;
            }
            if (!Screen.class.isAssignableFrom(method.getReturnType())) {
                continue;
            }
            try {
                method.setAccessible(true);
                Object value = method.invoke(minecraft);
                return value instanceof Screen screen ? screen : null;
            } catch (ReflectiveOperationException ignored) {
                // Try the field fallback below.
            }
        }
        return null;
    }

    private static Screen getScreenByField(Minecraft minecraft) {
        for (Field field : Minecraft.class.getDeclaredFields()) {
            if (!Screen.class.isAssignableFrom(field.getType())) {
                continue;
            }
            if (Modifier.isStatic(field.getModifiers())) {
                continue;
            }
            try {
                field.setAccessible(true);
                Object value = field.get(minecraft);
                return value instanceof Screen screen ? screen : null;
            } catch (ReflectiveOperationException ignored) {
                // Keep searching.
            }
        }
        return null;
    }

    private static boolean trySetScreenByMethod(Minecraft minecraft, Screen screen) {
        Method best = null;
        for (Method method : Minecraft.class.getDeclaredMethods()) {
            if (method.getParameterCount() != 1) {
                continue;
            }
            if (method.getReturnType() != Void.TYPE) {
                continue;
            }
            if (!method.getParameterTypes()[0].isAssignableFrom(Screen.class)) {
                continue;
            }

            String name = method.getName().toLowerCase();
            if (name.contains("screen")) {
                best = method;
                break;
            }
            if (best == null) {
                best = method;
            }
        }

        if (best == null) {
            return false;
        }

        try {
            best.setAccessible(true);
            best.invoke(minecraft, screen);
            return true;
        } catch (ReflectiveOperationException ignored) {
            return false;
        }
    }

    private static void initScreen(Minecraft minecraft, Screen screen) {
        int width = minecraft.getWindow().getGuiScaledWidth();
        int height = minecraft.getWindow().getGuiScaledHeight();

        try {
            Method initWithSize = Screen.class.getDeclaredMethod("init", int.class, int.class);
            initWithSize.setAccessible(true);
            initWithSize.invoke(screen, width, height);
            return;
        } catch (ReflectiveOperationException ignored) {
            // Fall back to the no-arg init below.
        }

        try {
            Method initNoArgs = Screen.class.getDeclaredMethod("init");
            initNoArgs.setAccessible(true);
            initNoArgs.invoke(screen);
        } catch (ReflectiveOperationException ignored) {
            // If neither init method can be reached, the screen field is still set;
            // Minecraft will usually initialize it on the next client UI tick.
        }
    }

    private static boolean trySetScreenByField(Minecraft minecraft, Screen screen) {
        for (Field field : Minecraft.class.getDeclaredFields()) {
            if (!Screen.class.isAssignableFrom(field.getType())) {
                continue;
            }
            if (Modifier.isStatic(field.getModifiers())) {
                continue;
            }
            try {
                field.setAccessible(true);
                field.set(minecraft, screen);
                initScreen(minecraft, screen);
                return true;
            } catch (ReflectiveOperationException ignored) {
                // Keep searching.
            }
        }
        return false;
    }
}

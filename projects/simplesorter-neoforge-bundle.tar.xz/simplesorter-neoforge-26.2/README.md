# Simple Sorter 0.9.2 - NeoForge 26.2 Beta

A radius-based Sorting Wand for Minecraft 26.2 / NeoForge 26.2 beta.

This is a direct beta port of the released 26.1.2 line. The gameplay feature set is intentionally kept the same, while the build target was moved to NeoForge 26.2.

## Requirements

- Minecraft 26.2
- NeoForge 26.2.0.1-beta or newer 26.2 beta build
- Java 25
- Gradle 9.1.0+

## Features

- Real radius-based container sorting around the player
- Per-wand mini GUI
- Configurable radius
- Sorting modes:
  - Match Existing
  - Smart Categories
  - Compact Stacks
  - Player Deposit
- Deposit Now button in the GUI
- Run Selected button in the GUI
- Rebindable client keybinds
- HUD usage hints while holding the wand
- Radius preview particles
- Sorted container highlights
- Transfer FX particles
- English and Russian localization

## 26.2 beta port notes

NeoForge 26.2 currently has an official ModDevGradle MDK template and the beta NeoForge version used here is `26.2.0.1-beta`.

JEI integration is intentionally disabled in this beta port. The mod works without JEI. The JEI info page should be restored only after JEI publishes a Minecraft 26.2-compatible NeoForge artifact.

Internally, the sorting system still uses NeoForge's deprecated `IItemHandler` compatibility layer through the transfer capability bridge. This is the same technical debt as the 26.1.2 release and should be handled as a separate storage-layer refactor later.

## Build

```bat
gradle build
```

Expected jar:

```text
build/libs/simplesorter-0.9.2-neoforge-26.2-beta.jar
```

## Testing checklist

1. Start a NeoForge 26.2 client with the generated jar.
2. Confirm the Sorting Wand appears in the creative tab.
3. Hold the wand and check HUD hints.
4. Open the GUI with Shift + RMB or the menu keybind.
5. Test Match Existing with mixed chests.
6. Test Compact Stacks inside messy containers.
7. Test Deposit Now from the GUI.
8. Test Run Selected from the GUI.
9. Test the quick sort keybind.
10. Test without JEI installed.

## Known limitations

- JEI is not included in this 26.2 beta port.
- `IItemHandler` warnings may appear during compilation. They are not fatal, but they show future technical debt.
- This project was prepared as a source port. Build verification should be done in the target Windows/Java/Gradle environment.

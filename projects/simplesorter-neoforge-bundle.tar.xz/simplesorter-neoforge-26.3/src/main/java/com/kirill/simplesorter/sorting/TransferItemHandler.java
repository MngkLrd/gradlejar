package com.kirill.simplesorter.sorting;

import net.minecraft.world.item.ItemStack;
import net.neoforged.neoforge.transfer.ResourceHandler;
import net.neoforged.neoforge.transfer.item.ItemResource;
import net.neoforged.neoforge.transfer.item.ItemUtil;
import net.neoforged.neoforge.transfer.transaction.Transaction;

/** Native NeoForge 26.3 transfer API adapter. Retains item component identity. */
public record TransferItemHandler(ResourceHandler<ItemResource> handler) implements IItemHandler {
    @Override public int getSlots() { return handler.size(); }
    @Override public ItemStack getStackInSlot(int slot) { return ItemUtil.getStack(handler, slot); }
    @Override public ItemStack insertItem(int slot, ItemStack stack, boolean simulate) {
        return ItemUtil.insertItemReturnRemaining(handler, slot, stack, simulate, null);
    }
    @Override public ItemStack extractItem(int slot, int amount, boolean simulate) {
        ItemStack previous = getStackInSlot(slot);
        if (previous.isEmpty() || amount <= 0) return ItemStack.EMPTY;
        int count = Math.min(previous.getCount(), amount);
        if (simulate) {
            try (Transaction tx = Transaction.openRoot()) {
                int extracted = handler.extract(slot, ItemResource.of(previous), count, tx);
                return previous.copyWithCount(extracted);
            }
        }
        try (Transaction tx = Transaction.openRoot()) {
            int extracted = handler.extract(slot, ItemResource.of(previous), count, tx);
            if (extracted > 0) tx.commit();
            return previous.copyWithCount(extracted);
        }
    }
}

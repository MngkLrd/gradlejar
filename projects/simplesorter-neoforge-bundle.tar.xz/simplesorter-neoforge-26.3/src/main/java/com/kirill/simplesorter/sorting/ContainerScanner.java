package com.kirill.simplesorter.sorting;

import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.Container;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.neoforged.neoforge.capabilities.Capabilities;
import net.neoforged.neoforge.transfer.ResourceHandler;
import net.neoforged.neoforge.transfer.item.ItemResource;
import net.neoforged.neoforge.transfer.item.VanillaContainerWrapper;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.IdentityHashMap;
import java.util.List;
import java.util.Set;

public final class ContainerScanner {
    private ContainerScanner() {}

    public static List<ContainerRef> scanRadius(ServerLevel level, BlockPos center, int radius) {
        int safeRadius = Math.max(1, radius);
        int minX = center.getX() - safeRadius;
        int maxX = center.getX() + safeRadius;
        int minY = center.getY() - safeRadius;
        int maxY = center.getY() + safeRadius;
        int minZ = center.getZ() - safeRadius;
        int maxZ = center.getZ() + safeRadius;

        return scanBoxInRadius(level, new BlockPos(minX, minY, minZ), new BlockPos(maxX, maxY, maxZ), center, safeRadius);
    }

    public static List<ContainerRef> scanBoxInRadius(ServerLevel level, BlockPos min, BlockPos max, BlockPos center, int radius) {
        List<ContainerRef> result = new ArrayList<>();
        Set<Object> seen = java.util.Collections.newSetFromMap(new IdentityHashMap<>());
        int radiusSquared = radius * radius;

        for (BlockPos pos : collectCandidatePositions(level, min, max, center, radiusSquared)) {
            if (!level.isInWorldBounds(pos)) {
                continue;
            }

            if (!isInsideRadius(center, pos, radiusSquared)) {
                continue;
            }

            if (!level.hasChunkAt(pos)) {
                continue;
            }

            BlockEntity blockEntity = level.getBlockEntity(pos);
            if (blockEntity == null) {
                continue;
            }

            ResourceHandler<ItemResource> resourceHandler = level.getCapability(
                    Capabilities.Item.BLOCK,
                    pos,
                    level.getBlockState(pos),
                    blockEntity,
                    null
            );
            Object identity = blockEntity;

            if (resourceHandler == null && blockEntity instanceof Container container) {
                if (container.getContainerSize() <= 0) {
                    continue;
                }
                resourceHandler = VanillaContainerWrapper.of(container);
                identity = container;
            }

            IItemHandler handler = resourceHandler == null ? null : new TransferItemHandler(resourceHandler);
            if (handler == null || handler.getSlots() <= 0) {
                continue;
            }

            if (!seen.add(identity)) {
                continue;
            }

            result.add(new ContainerRef(pos.immutable(), handler, identity, level));
        }

        return result;
    }

    private static List<BlockPos> collectCandidatePositions(ServerLevel level, BlockPos min, BlockPos max, BlockPos center, int radiusSquared) {
        List<BlockPos> positions = new ArrayList<>();
        int minChunkX = Math.floorDiv(min.getX(), 16);
        int maxChunkX = Math.floorDiv(max.getX(), 16);
        int minChunkZ = Math.floorDiv(min.getZ(), 16);
        int maxChunkZ = Math.floorDiv(max.getZ(), 16);
        for (int chunkX = minChunkX; chunkX <= maxChunkX; chunkX++) {
            for (int chunkZ = minChunkZ; chunkZ <= maxChunkZ; chunkZ++) {
                BlockPos probe = new BlockPos(chunkX << 4, center.getY(), chunkZ << 4);
                if (!level.hasChunkAt(probe)) continue;
                for (BlockPos pos : level.getChunk(chunkX, chunkZ).getBlockEntitiesPos()) {
                    if (pos.getX() < min.getX() || pos.getX() > max.getX()
                            || pos.getY() < min.getY() || pos.getY() > max.getY()
                            || pos.getZ() < min.getZ() || pos.getZ() > max.getZ()) continue;
                    if (isInsideRadius(center, pos, radiusSquared)) positions.add(pos.immutable());
                }
            }
        }
        positions.sort(Comparator.comparingDouble(pos -> pos.distSqr(center)));
        return positions.subList(0, Math.min(positions.size(), 160));
    }

    private static boolean isInsideRadius(BlockPos center, BlockPos pos, int radiusSquared) {
        int dx = pos.getX() - center.getX();
        int dy = pos.getY() - center.getY();
        int dz = pos.getZ() - center.getZ();
        return dx * dx + dy * dy + dz * dz <= radiusSquared;
    }
}

package com.kirill.simplesorter.client;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.screens.Screen;
public final class ClientScreenAccess {
    private ClientScreenAccess() {}
    public static boolean hasScreen(Minecraft minecraft) { return minecraft.gui.screen() != null; }
    public static Screen getCurrentScreen(Minecraft minecraft) { return minecraft.gui.screen(); }
    public static void openScreen(Minecraft minecraft, Screen screen) { minecraft.gui.setScreen(screen); }
}

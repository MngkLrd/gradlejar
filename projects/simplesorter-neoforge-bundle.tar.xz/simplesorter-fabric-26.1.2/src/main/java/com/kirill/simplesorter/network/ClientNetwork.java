package com.kirill.simplesorter.network;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
public final class ClientNetwork {
 private ClientNetwork(){}
 public static void send(WandSettingsPayload payload){ClientPlayNetworking.send(payload);}
 public static void send(WandActionPayload payload){ClientPlayNetworking.send(payload);}
}

package com.kirill.simplesorter.sorting;
import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.Container;
import net.minecraft.world.level.block.entity.BlockEntity;
import java.util.*;
public final class ContainerScanner {
 private ContainerScanner(){}
 public static List<ContainerRef> scanRadius(ServerLevel level,BlockPos center,int radius){
  int r=Math.min(32,Math.max(1,radius));
  return scanBoxInRadius(level,center.offset(-r,-r,-r),center.offset(r,r,r),center,r);
 }
 public static List<ContainerRef> scanBoxInRadius(ServerLevel level,BlockPos min,BlockPos max,BlockPos center,int radius){
  List<BlockPos> positions=new ArrayList<>();int squared=radius*radius;
  for(int cx=Math.floorDiv(min.getX(),16);cx<=Math.floorDiv(max.getX(),16);cx++){
   for(int cz=Math.floorDiv(min.getZ(),16);cz<=Math.floorDiv(max.getZ(),16);cz++){
    BlockPos probe=new BlockPos(cx<<4,center.getY(),cz<<4);
    if(!level.hasChunkAt(probe))continue;
    for(BlockPos pos:level.getChunk(cx,cz).getBlockEntitiesPos()){
     if(pos.getX()<min.getX()||pos.getX()>max.getX()||pos.getY()<min.getY()||pos.getY()>max.getY()||pos.getZ()<min.getZ()||pos.getZ()>max.getZ())continue;
     int dx=pos.getX()-center.getX(),dy=pos.getY()-center.getY(),dz=pos.getZ()-center.getZ();
     if(dx*dx+dy*dy+dz*dz<=squared) positions.add(pos.immutable());
    }
   }
  }
  positions.sort(Comparator.comparingDouble(p->p.distSqr(center)));
  List<ContainerRef> result=new ArrayList<>();
  Set<Object>seen=Collections.newSetFromMap(new IdentityHashMap<>());
  for(BlockPos pos:positions.subList(0,Math.min(160,positions.size()))){
   BlockEntity be=level.getBlockEntity(pos);
   if(!(be instanceof Container container)||container.getContainerSize()==0||!seen.add(be))continue;
   result.add(new ContainerRef(pos,new ContainerItemHandler(container),be,level));
  }
  return result;
 }
}

package com.kirill.simplesorter.sorting;

import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import com.kirill.simplesorter.sorting.IItemHandler;

public record ContainerRef(BlockPos pos, IItemHandler handler, Object identity, ServerLevel level) {
    public int size() {
        return handler.getSlots();
    }
}

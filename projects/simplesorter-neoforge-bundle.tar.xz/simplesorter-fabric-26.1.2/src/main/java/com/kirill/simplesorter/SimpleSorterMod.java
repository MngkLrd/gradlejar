package com.kirill.simplesorter;
import com.kirill.simplesorter.registry.ModItems;
import com.kirill.simplesorter.network.ModNetworking;
import net.fabricmc.api.ModInitializer;
public final class SimpleSorterMod implements ModInitializer {
 public static final String MOD_ID="simplesorter";
 @Override public void onInitialize(){ModItems.initialize();ModNetworking.register();}
}

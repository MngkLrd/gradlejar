package com.kirill.simplesorter.network;
import net.fabricmc.fabric.api.networking.v1.PayloadTypeRegistry;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
public final class ModNetworking{
 private ModNetworking(){}
 public static void register(){
  PayloadTypeRegistry.serverboundPlay().register(WandSettingsPayload.TYPE,WandSettingsPayload.STREAM_CODEC);
  PayloadTypeRegistry.serverboundPlay().register(WandActionPayload.TYPE,WandActionPayload.STREAM_CODEC);
  ServerPlayNetworking.registerGlobalReceiver(WandSettingsPayload.TYPE,WandSettingsPayload::handle);
  ServerPlayNetworking.registerGlobalReceiver(WandActionPayload.TYPE,WandActionPayload::handle);
 }
}

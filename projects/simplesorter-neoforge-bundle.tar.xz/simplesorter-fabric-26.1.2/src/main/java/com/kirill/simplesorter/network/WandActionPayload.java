package com.kirill.simplesorter.network;

import com.kirill.simplesorter.SimpleSorterMod;
import com.kirill.simplesorter.item.SortingWandItem;
import com.kirill.simplesorter.registry.ModItems;
import com.kirill.simplesorter.settings.SortingMode;
import com.kirill.simplesorter.settings.SortingWandSettings;
import com.kirill.simplesorter.sorting.SortingManager;
import com.kirill.simplesorter.sorting.SortingResult;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.Identifier;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;

public record WandActionPayload(
        int handIndex,
        int storedModeIndex,
        int actionModeIndex,
        int radius,
        boolean showRadius,
        boolean showContainerHighlights,
        boolean showTransferParticles
) implements CustomPacketPayload {
    public static final Type<WandActionPayload> TYPE = new Type<>(Identifier.fromNamespaceAndPath(SimpleSorterMod.MOD_ID, "wand_action"));

    public static final StreamCodec<RegistryFriendlyByteBuf, WandActionPayload> STREAM_CODEC = new StreamCodec<>() {
        @Override
        public WandActionPayload decode(RegistryFriendlyByteBuf buffer) {
            return new WandActionPayload(
                    buffer.readVarInt(),
                    buffer.readVarInt(),
                    buffer.readVarInt(),
                    buffer.readVarInt(),
                    buffer.readBoolean(),
                    buffer.readBoolean(),
                    buffer.readBoolean()
            );
        }

        @Override
        public void encode(RegistryFriendlyByteBuf buffer, WandActionPayload payload) {
            buffer.writeVarInt(payload.handIndex());
            buffer.writeVarInt(payload.storedModeIndex());
            buffer.writeVarInt(payload.actionModeIndex());
            buffer.writeVarInt(payload.radius());
            buffer.writeBoolean(payload.showRadius());
            buffer.writeBoolean(payload.showContainerHighlights());
            buffer.writeBoolean(payload.showTransferParticles());
        }
    };

    public static WandActionPayload run(InteractionHand hand, SortingWandSettings storedSettings, SortingMode actionMode) {
        SortingWandSettings safe = storedSettings.sanitized();
        SortingMode safeActionMode = actionMode == null ? safe.mode() : actionMode;
        return new WandActionPayload(
                hand == InteractionHand.OFF_HAND ? 1 : 0,
                safe.mode().index(),
                safeActionMode.index(),
                safe.radius(),
                safe.showRadius(),
                safe.showContainerHighlights(),
                safe.showTransferParticles()
        );
    }

    @Override
    public Type<? extends CustomPacketPayload> type() {
        return TYPE;
    }

    public static void handle(WandActionPayload payload, Player player) {
            ItemStack stack = payload.handIndex() == 1 ? player.getOffhandItem() : player.getMainHandItem();
            if (stack.isEmpty() || stack.getItem() != ModItems.SORTING_WAND) {
                return;
            }
            if (!(player.level() instanceof ServerLevel serverLevel)) {
                return;
            }
            if (player.getCooldowns().isOnCooldown(stack)) {
                return;
            }

            SortingWandSettings storedSettings = new SortingWandSettings(
                    SortingMode.byIndex(payload.storedModeIndex()),
                    payload.radius(),
                    payload.showRadius(),
                    payload.showContainerHighlights(),
                    payload.showTransferParticles()
            ).sanitized();
            storedSettings.writeTo(stack);

            SortingWandSettings actionSettings = storedSettings.withMode(SortingMode.byIndex(payload.actionModeIndex()));
            SortingResult result = SortingManager.sortAroundPlayer(serverLevel, player, actionSettings);
            player.getCooldowns().addCooldown(stack, SortingWandItem.COOLDOWN_TICKS);
            player.sendOverlayMessage(result.toPlayerMessageComponent());

            if (result.used()) {
                SortingWandItem.consumeUse(stack, player);
            }
    }
}

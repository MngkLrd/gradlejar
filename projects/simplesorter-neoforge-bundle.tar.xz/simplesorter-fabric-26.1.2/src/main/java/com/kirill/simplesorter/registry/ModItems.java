package com.kirill.simplesorter.registry;
import com.kirill.simplesorter.item.SortingWandItem;
import net.minecraft.core.Registry;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceKey;
import net.minecraft.resources.Identifier;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.CreativeModeTabs;
import net.fabricmc.fabric.api.creativetab.v1.CreativeModeTabEvents;
public final class ModItems {
 private ModItems(){}
 public static final Identifier ID=Identifier.fromNamespaceAndPath("simplesorter","sorting_wand");
 public static final ResourceKey<Item> KEY=ResourceKey.create(Registries.ITEM,ID);
 public static final SortingWandItem SORTING_WAND=Registry.register(BuiltInRegistries.ITEM,KEY,
    new SortingWandItem(new Item.Properties().setId(KEY).stacksTo(1).durability(128)));
 public static void initialize(){
  CreativeModeTabEvents.modifyOutputEvent(CreativeModeTabs.TOOLS_AND_UTILITIES).register(e->e.accept(SORTING_WAND));
 }
}

package com.kirill.simplesorter.registry;
import com.kirill.simplesorter.item.SortingWandItem;
import net.fabricmc.fabric.api.itemgroup.v1.ItemGroupEvents;
import net.minecraft.core.Registry;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.Identifier;
import net.minecraft.resources.ResourceKey;
import net.minecraft.world.item.CreativeModeTabs;
import net.minecraft.world.item.Item;
public final class ModItems {
 private ModItems(){}
 public static final Identifier ITEM_ID=Identifier.fromNamespaceAndPath("simplesorter","sorting_wand");
 public static final Item SORTING_WAND=Registry.register(BuiltInRegistries.ITEM, ITEM_ID,
  new SortingWandItem(new Item.Properties().setId(ResourceKey.create(Registries.ITEM, ITEM_ID)).stacksTo(1).durability(128)));
 public static void init(){ ItemGroupEvents.modifyEntriesEvent(CreativeModeTabs.TOOLS_AND_UTILITIES).register(entries->entries.accept(SORTING_WAND)); }
}

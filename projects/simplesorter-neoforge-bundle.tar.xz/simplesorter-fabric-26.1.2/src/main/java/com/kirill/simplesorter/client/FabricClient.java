package com.kirill.simplesorter.client;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.rendering.v1.hud.HudElementRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.hud.VanillaHudElements;
import net.minecraft.resources.Identifier;
public class FabricClient implements ClientModInitializer {
 @Override public void onInitializeClient(){
  ClientKeyMappings.init();
  ClientTickEvents.END_CLIENT_TICK.register(ClientEventHandler::onClientTick);
  HudElementRegistry.attachElementAfter(VanillaHudElements.HOTBAR,
    Identifier.fromNamespaceAndPath("simplesorter","wand_hints"),
    (graphics,delta)->ClientEventHandler.onRenderGui(graphics));
 }
}

package com.kirill.simplesorter.sorting;
import net.minecraft.world.Container;
import net.minecraft.world.item.ItemStack;
public record ContainerItemHandler(Container container) implements IItemHandler {
 public int getSlots(){return container.getContainerSize();}
 public ItemStack getStackInSlot(int slot){return container.getItem(slot);}
 public ItemStack insertItem(int slot,ItemStack stack,boolean simulate){
  if(stack.isEmpty()||!container.canPlaceItem(slot,stack))return stack;
  ItemStack existing=container.getItem(slot);
  if(!existing.isEmpty()&&!ItemStack.isSameItemSameComponents(existing,stack))return stack;
  int limit=Math.min(container.getMaxStackSize(),stack.getMaxStackSize());
  int room=Math.max(0,limit-existing.getCount());
  int accepted=Math.min(stack.getCount(),room);
  if(accepted<=0)return stack;
  if(!simulate){
   if(existing.isEmpty())container.setItem(slot,stack.copyWithCount(accepted));
   else {ItemStack updated=existing.copy();updated.grow(accepted);container.setItem(slot,updated);}
   container.setChanged();
  }
  ItemStack left=stack.copy();left.shrink(accepted);return left;
 }
 public ItemStack extractItem(int slot,int count,boolean simulate){
  if(count<=0)return ItemStack.EMPTY;
  ItemStack existing=container.getItem(slot);
  if(existing.isEmpty())return ItemStack.EMPTY;
  int take=Math.min(count,existing.getCount());
  if(simulate)return existing.copyWithCount(take);
  ItemStack out=container.removeItem(slot,take);container.setChanged();return out;
 }
}

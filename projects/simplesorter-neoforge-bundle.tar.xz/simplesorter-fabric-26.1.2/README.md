Simple Sorter Fabric 26.1.2, Java 25. Initial port; tested via GitHub CI.

package com.kirill.simplesorter.client;
import com.mojang.blaze3d.platform.InputConstants;
import net.minecraft.client.KeyMapping;
import net.minecraft.resources.Identifier;
import net.fabricmc.fabric.api.client.keymapping.v1.KeyMappingHelper;
public final class ClientKeyMappings{
 private ClientKeyMappings(){}
 public static final KeyMapping.Category CATEGORY=new KeyMapping.Category(Identifier.fromNamespaceAndPath("simplesorter","main"));
 public static final KeyMapping OPEN_SETTINGS=new KeyMapping("key.simplesorter.open_settings", InputConstants.KEY_G,CATEGORY);
 public static final KeyMapping QUICK_SORT=new KeyMapping("key.simplesorter.quick_sort", InputConstants.KEY_H,CATEGORY);
 public static void init(){KeyMappingHelper.registerKeyMapping(OPEN_SETTINGS);KeyMappingHelper.registerKeyMapping(QUICK_SORT);}
}

Simple Sorter Fabric 26.3, Java 25. Initial port; tested via GitHub CI.

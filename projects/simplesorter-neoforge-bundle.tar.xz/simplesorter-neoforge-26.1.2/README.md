# Simple Sorter 0.8.4 - NeoForge 26.1.2 Port

A radius-based Sorting Wand for NeoForge 26.1.2.

## Requirements

- Java 25
- Gradle 9.1.0 or newer
- NeoForge 26.1.2

## Features preserved from 1.21.1 / 0.7.2

- Radius-based nearby container sorting
- Per-wand mini settings GUI
- Match Existing, Smart Categories, Compact Stacks, Player Deposit modes
- Run Selected and Deposit Now buttons
- Rebindable client keys
- HUD usage hints
- Radius particles, sorted container highlights, Transfer FX
- English and Russian localization

## 26.1.2 port notes

This build removes the old chunk-based behavior and keeps the final 0.7.2 gameplay.

The inventory bridge now uses the 26.1.2 transfer capability lookup first. Vanilla `Container` fallback uses `VanillaContainerWrapper` instead of the old `InvWrapper`. Internally the sorting algorithm still uses NeoForge `IItemHandler` through the compatibility adapter because rewriting the whole mover to native transfer resources would be a larger storage-system refactor.

JEI integration is intentionally disabled in this port. The core mod does not depend on JEI and should be brought up first. Re-add the JEI info page only after the base 26.1.2 jar compiles cleanly.

## Build

```bat
gradle build
```

Expected jar:

```text
build/libs/simplesorter-0.8.4-neoforge-26.1.2.jar
```


## JEI integration

JEI is restored in this port as an optional integration. The mod compiles against JEI API artifacts and adds an item information page for the Sorting Wand when JEI is installed. JEI is not bundled into the Simple Sorter jar.

Target JEI version: `29.6.2.31` for NeoForge `26.1.2`.

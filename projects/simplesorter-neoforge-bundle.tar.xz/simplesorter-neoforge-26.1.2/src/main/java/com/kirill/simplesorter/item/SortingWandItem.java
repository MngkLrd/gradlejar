package com.kirill.simplesorter.item;

import com.kirill.simplesorter.settings.SortingWandSettings;
import com.kirill.simplesorter.sorting.SortingManager;
import com.kirill.simplesorter.sorting.SortingResult;
import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.item.component.TooltipDisplay;
import net.minecraft.world.item.context.UseOnContext;
import net.minecraft.world.level.Level;

import java.util.function.Consumer;

public class SortingWandItem extends Item {
    public static final int COOLDOWN_TICKS = 50;

    public SortingWandItem(Properties properties) {
        super(properties);
    }

    @Override
    public InteractionResult use(Level level, Player player, InteractionHand hand) {
        ItemStack stack = player.getItemInHand(hand);

        if (level.isClientSide()) {
            if (player.isShiftKeyDown()) {
                openSettingsScreenOnClient(stack, hand);
            }
            return InteractionResult.SUCCESS;
        }

        if (!(level instanceof ServerLevel serverLevel)) {
            return InteractionResult.PASS;
        }

        if (player.isShiftKeyDown()) {
            return InteractionResult.SUCCESS_SERVER;
        }

        if (player.getCooldowns().isOnCooldown(stack)) {
            return InteractionResult.FAIL;
        }

        SortingWandSettings settings = SortingWandSettings.readFrom(stack);
        SortingResult result = SortingManager.sortAroundPlayer(serverLevel, player, settings);
        player.getCooldowns().addCooldown(stack, COOLDOWN_TICKS);

        if (result.used()) {
            consumeUse(stack, player);
        }

        return InteractionResult.SUCCESS_SERVER;
    }

    @Override
    public InteractionResult useOn(UseOnContext context) {
        Player player = context.getPlayer();
        ItemStack stack = context.getItemInHand();

        if (player != null && player.isShiftKeyDown()) {
            if (context.getLevel().isClientSide()) {
                openSettingsScreenOnClient(stack, context.getHand());
            }
            return InteractionResult.SUCCESS;
        }

        return InteractionResult.PASS;
    }

    private static void openSettingsScreenOnClient(ItemStack stack, InteractionHand hand) {
        try {
            Class<?> openerClass = Class.forName("com.kirill.simplesorter.client.ClientScreenOpener");
            openerClass.getMethod("openWandSettings", ItemStack.class, InteractionHand.class).invoke(null, stack, hand);
        } catch (ReflectiveOperationException exception) {
            // Client hook is intentionally reflective so this common item class never directly links Minecraft client classes.
        }
    }

    public static void consumeUse(ItemStack stack, Player player) {
        if (player.getAbilities().instabuild || !stack.isDamageableItem()) {
            return;
        }

        int newDamage = stack.getDamageValue() + 1;
        if (newDamage >= stack.getMaxDamage()) {
            stack.shrink(1);
            player.sendOverlayMessage(Component.translatable("message.simplesorter.wand_broke"));
        } else {
            stack.setDamageValue(newDamage);
        }
    }

    private static Component onOff(boolean value) {
        return Component.translatable(value ? "tooltip.simplesorter.on" : "tooltip.simplesorter.off");
    }

    @Override
    public void appendHoverText(ItemStack stack, Item.TooltipContext context, TooltipDisplay display, Consumer<Component> tooltip, TooltipFlag flag) {
        SortingWandSettings settings = SortingWandSettings.readFrom(stack);
        tooltip.accept(Component.translatable("tooltip.simplesorter.sorting_wand.1").withStyle(ChatFormatting.GRAY));
        tooltip.accept(Component.translatable("tooltip.simplesorter.sorting_wand.mode", Component.translatable(settings.mode().translationKey())).withStyle(ChatFormatting.GOLD));
        tooltip.accept(Component.translatable("tooltip.simplesorter.sorting_wand.radius", settings.radius()).withStyle(ChatFormatting.AQUA));
        tooltip.accept(Component.translatable("tooltip.simplesorter.sorting_wand.visuals",
                onOff(settings.showRadius()),
                onOff(settings.showContainerHighlights()),
                onOff(settings.showTransferParticles())
        ).withStyle(ChatFormatting.DARK_GRAY));
        tooltip.accept(Component.translatable("tooltip.simplesorter.sorting_wand.2").withStyle(ChatFormatting.DARK_GRAY));
        tooltip.accept(Component.translatable("tooltip.simplesorter.sorting_wand.3").withStyle(ChatFormatting.DARK_GRAY));
    }
}

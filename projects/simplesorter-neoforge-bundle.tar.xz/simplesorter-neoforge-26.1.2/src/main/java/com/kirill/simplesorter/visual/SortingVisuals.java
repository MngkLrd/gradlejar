package com.kirill.simplesorter.visual;

import com.kirill.simplesorter.config.SorterSettings;
import com.kirill.simplesorter.settings.SortingWandSettings;
import com.kirill.simplesorter.sorting.MoveRecord;
import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.ItemParticleOption;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.phys.Vec3;

import java.util.List;
import java.util.Set;

public final class SortingVisuals {
    private SortingVisuals() {}

    public static void playSortingEffects(ServerLevel level, Set<BlockPos> changedContainers, List<MoveRecord> moves, SortingWandSettings settings) {
        SortingWandSettings safe = settings.sanitized();

        if (safe.showContainerHighlights()) {
            int highlighted = 0;
            for (BlockPos pos : changedContainers) {
                highlightContainer(level, pos);
                highlighted++;
                if (highlighted >= SorterSettings.MAX_HIGHLIGHTED_CONTAINERS) {
                    break;
                }
            }
        }

        if (safe.showTransferParticles()) {
            int traced = 0;
            for (MoveRecord move : moves) {
                drawItemFlight(level, move);
                traced++;
                if (traced >= SorterSettings.MAX_MOVE_PARTICLE_TRACES) {
                    break;
                }
            }
        }
    }

    private static void highlightContainer(ServerLevel level, BlockPos pos) {
        double minX = pos.getX() + 0.12D;
        double maxX = pos.getX() + 0.88D;
        double minZ = pos.getZ() + 0.12D;
        double maxZ = pos.getZ() + 0.88D;
        double y = pos.getY() + 1.08D;

        level.sendParticles(ParticleTypes.HAPPY_VILLAGER, pos.getX() + 0.5D, y, pos.getZ() + 0.5D, 6, 0.25D, 0.1D, 0.25D, 0.0D);
        level.sendParticles(ParticleTypes.END_ROD, minX, y, minZ, 1, 0.0D, 0.01D, 0.0D, 0.0D);
        level.sendParticles(ParticleTypes.END_ROD, maxX, y, minZ, 1, 0.0D, 0.01D, 0.0D, 0.0D);
        level.sendParticles(ParticleTypes.END_ROD, minX, y, maxZ, 1, 0.0D, 0.01D, 0.0D, 0.0D);
        level.sendParticles(ParticleTypes.END_ROD, maxX, y, maxZ, 1, 0.0D, 0.01D, 0.0D, 0.0D);
    }

    private static void drawItemFlight(ServerLevel level, MoveRecord move) {
        if (move.visualStack().isEmpty() || move.sourcePos().equals(move.targetPos())) {
            return;
        }

        Vec3 from = Vec3.atCenterOf(move.sourcePos()).add(0.0D, 0.55D, 0.0D);
        Vec3 to = Vec3.atCenterOf(move.targetPos()).add(0.0D, 0.55D, 0.0D);
        Vec3 delta = to.subtract(from);
        double length = delta.length();
        if (length <= 0.1D) {
            return;
        }

        Vec3 velocity = delta.normalize().scale(0.06D);
        int steps = Math.max(4, Math.min(14, (int) Math.ceil(length / 1.75D)));
        ItemParticleOption itemParticle = new ItemParticleOption(ParticleTypes.ITEM, move.visualStack().getItem());

        for (int i = 0; i <= steps; i++) {
            double t = (double) i / (double) steps;
            Vec3 point = from.add(delta.scale(t)).add(0.0D, Math.sin(t * Math.PI) * 0.45D, 0.0D);
            level.sendParticles(itemParticle, point.x, point.y, point.z, 1, velocity.x, 0.025D, velocity.z, 0.02D);
            if (i % 2 == 0) {
                level.sendParticles(ParticleTypes.END_ROD, point.x, point.y, point.z, 1, 0.0D, 0.01D, 0.0D, 0.0D);
            }
        }
    }
}

package com.kirill.simplesorter.network;

import com.kirill.simplesorter.SimpleSorterMod;
import net.neoforged.neoforge.network.event.RegisterPayloadHandlersEvent;
import net.neoforged.neoforge.network.registration.PayloadRegistrar;

public final class ModNetworking {
    private ModNetworking() {}

    public static void register(RegisterPayloadHandlersEvent event) {
        PayloadRegistrar registrar = event.registrar(SimpleSorterMod.MOD_ID).versioned("1.0");
        registrar.playToServer(WandSettingsPayload.TYPE, WandSettingsPayload.STREAM_CODEC, WandSettingsPayload::handle);
        registrar.playToServer(WandActionPayload.TYPE, WandActionPayload.STREAM_CODEC, WandActionPayload::handle);
    }
}

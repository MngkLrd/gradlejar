package com.kirill.simplesorter.registry;

import com.kirill.simplesorter.SimpleSorterMod;
import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.ItemStack;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.registries.DeferredRegister;

public final class ModCreativeTabs {
    private ModCreativeTabs() {}

    public static final DeferredRegister<CreativeModeTab> CREATIVE_TABS =
            DeferredRegister.create(Registries.CREATIVE_MODE_TAB, SimpleSorterMod.MOD_ID);

    public static final DeferredHolder<CreativeModeTab, CreativeModeTab> SIMPLE_SORTER_TAB = CREATIVE_TABS.register("simple_sorter_tab",
            () -> CreativeModeTab.builder()
                    .title(Component.translatable("itemGroup.simplesorter"))
                    .icon(() -> new ItemStack(ModItems.SORTING_WAND.get()))
                    .displayItems((parameters, output) -> output.accept(ModItems.SORTING_WAND.get()))
                    .build());

    public static void register(IEventBus eventBus) {
        CREATIVE_TABS.register(eventBus);
    }
}

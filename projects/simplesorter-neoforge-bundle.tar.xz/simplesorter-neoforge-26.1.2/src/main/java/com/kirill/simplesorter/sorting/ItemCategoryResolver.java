package com.kirill.simplesorter.sorting;

import net.minecraft.core.component.DataComponents;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.resources.Identifier;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;

import java.util.Locale;

public final class ItemCategoryResolver {
    private ItemCategoryResolver() {}

    public static SortCategory resolve(ItemStack stack) {
        return resolveDetailed(stack).category();
    }

    public static CategoryResolution resolveDetailed(ItemStack stack) {
        if (stack.isEmpty()) {
            return new CategoryResolution(SortCategoryRegistry.misc(), "empty stack");
        }

        Item item = stack.getItem();
        Identifier itemId = BuiltInRegistries.ITEM.getKey(item);
        String namespace = SortCategory.normalizeToken(itemId.getNamespace());
        String path = SortCategory.normalizeToken(itemId.getPath());

        for (SortCategory category : SortCategoryRegistry.categories()) {
            for (Identifier exact : category.itemIds()) {
                if (exact.equals(itemId)) {
                    return new CategoryResolution(category, "exact item " + itemId);
                }
            }

            for (var tag : category.tags()) {
                if (stack.is(tag)) {
                    return new CategoryResolution(category, "tag " + tag.location());
                }
            }

            for (ClassHint hint : category.classHints()) {
                if (matchesClassHint(stack, item, path, hint)) {
                    return new CategoryResolution(category, "class hint " + hint.name().toLowerCase(Locale.ROOT));
                }
            }

            for (String token : category.idContains()) {
                if (!token.isBlank() && path.contains(token)) {
                    return new CategoryResolution(category, "id contains " + token);
                }
            }

            for (String categoryNamespace : category.namespaces()) {
                if (!categoryNamespace.isBlank() && namespace.equals(categoryNamespace)) {
                    return new CategoryResolution(category, "namespace " + namespace);
                }
            }
        }

        return new CategoryResolution(SortCategoryRegistry.misc(), "fallback misc");
    }

    private static boolean matchesClassHint(ItemStack stack, Item item, String path, ClassHint hint) {
        return switch (hint) {
            case ARMOR -> isArmorPath(path) || item == Items.ELYTRA;
            case WEAPON -> isWeaponPath(path);
            case TOOL -> isToolPath(path) || item == Items.SHIELD;
            case FOOD -> stack.get(DataComponents.FOOD) != null;
            case BLOCK -> item instanceof BlockItem;
            case POTION -> item == Items.POTION || item == Items.SPLASH_POTION || item == Items.LINGERING_POTION;
            case BOOK -> item == Items.BOOK || item == Items.WRITABLE_BOOK || item == Items.WRITTEN_BOOK || item == Items.ENCHANTED_BOOK || item == Items.KNOWLEDGE_BOOK;
        };
    }

    private static boolean isArmorPath(String path) {
        return path.endsWith("_helmet")
                || path.endsWith("_chestplate")
                || path.endsWith("_leggings")
                || path.endsWith("_boots")
                || path.endsWith("_horse_armor")
                || path.contains("armor");
    }

    private static boolean isWeaponPath(String path) {
        return path.equals("bow")
                || path.equals("crossbow")
                || path.equals("trident")
                || path.equals("mace")
                || path.endsWith("_sword")
                || path.endsWith("_dagger")
                || path.endsWith("_spear");
    }

    private static boolean isToolPath(String path) {
        return path.equals("shears")
                || path.equals("fishing_rod")
                || path.equals("carrot_on_a_stick")
                || path.equals("warped_fungus_on_a_stick")
                || path.equals("flint_and_steel")
                || path.equals("brush")
                || path.equals("shield")
                || path.endsWith("_pickaxe")
                || path.endsWith("_axe")
                || path.endsWith("_shovel")
                || path.endsWith("_hoe")
                || path.endsWith("_hammer")
                || path.endsWith("_saw")
                || path.endsWith("_wrench");
    }
}

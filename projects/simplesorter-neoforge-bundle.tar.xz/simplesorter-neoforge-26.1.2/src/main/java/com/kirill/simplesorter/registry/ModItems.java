package com.kirill.simplesorter.registry;

import com.kirill.simplesorter.SimpleSorterMod;
import com.kirill.simplesorter.item.SortingWandItem;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.neoforge.registries.DeferredItem;
import net.neoforged.neoforge.registries.DeferredRegister;

public final class ModItems {
    private ModItems() {}

    public static final DeferredRegister.Items ITEMS = DeferredRegister.createItems(SimpleSorterMod.MOD_ID);

    public static final DeferredItem<SortingWandItem> SORTING_WAND = ITEMS.registerItem(
            "sorting_wand",
            SortingWandItem::new,
            properties -> properties.stacksTo(1).durability(128)
    );

    public static void register(IEventBus eventBus) {
        ITEMS.register(eventBus);
    }
}

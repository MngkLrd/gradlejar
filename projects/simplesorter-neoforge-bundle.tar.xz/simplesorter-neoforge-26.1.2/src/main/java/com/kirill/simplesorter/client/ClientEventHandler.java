package com.kirill.simplesorter.client;

import com.kirill.simplesorter.SimpleSorterMod;
import com.kirill.simplesorter.network.WandActionPayload;
import com.kirill.simplesorter.registry.ModItems;
import com.kirill.simplesorter.settings.SortingWandSettings;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.client.event.ClientTickEvent;
import net.neoforged.neoforge.client.event.RenderGuiEvent;
import net.neoforged.neoforge.client.network.ClientPacketDistributor;

@EventBusSubscriber(modid = SimpleSorterMod.MOD_ID, value = Dist.CLIENT)
public final class ClientEventHandler {
    private static final int HUD_TEXT = 0xFFEDE2CC;
    private static final int HUD_MUTED = 0xFFB5AA9B;
    private static final int HUD_BG = 0x99000000;

    private ClientEventHandler() {}

    @SubscribeEvent
    public static void onClientTick(ClientTickEvent.Post event) {
        Minecraft minecraft = Minecraft.getInstance();
        if (minecraft.level == null || minecraft.player == null) {
            return;
        }

        Player player = minecraft.player;
        HeldWand heldWand = getHeldWandWithHand(player);
        if (heldWand.stack().isEmpty()) {
            return;
        }

        handleKeybinds(minecraft, player, heldWand);

        SortingWandSettings settings = SortingWandSettings.readFrom(heldWand.stack());
        if (!settings.showRadius()) {
            return;
        }

        if (player.tickCount % 6 != 0) {
            return;
        }

        showSortingRadius(minecraft, player, settings.radius());
    }

    @SubscribeEvent
    public static void onRenderGui(RenderGuiEvent.Post event) {
        Minecraft minecraft = Minecraft.getInstance();
        if (minecraft.level == null || minecraft.player == null || minecraft.screen != null) {
            return;
        }

        HeldWand heldWand = getHeldWandWithHand(minecraft.player);
        if (heldWand.stack().isEmpty()) {
            return;
        }

        drawWandHints(minecraft, event.getGuiGraphics(), heldWand.stack());
    }

    private static void handleKeybinds(Minecraft minecraft, Player player, HeldWand heldWand) {
        while (ClientKeyMappings.OPEN_SETTINGS.consumeClick()) {
            ClientScreenOpener.openWandSettings(heldWand.stack(), heldWand.hand());
        }

        while (ClientKeyMappings.QUICK_SORT.consumeClick()) {
            if (minecraft.screen == null) {
                SortingWandSettings settings = SortingWandSettings.readFrom(heldWand.stack());
                ClientPacketDistributor.sendToServer(WandActionPayload.run(heldWand.hand(), settings, settings.mode()));
                player.swing(heldWand.hand());
            }
        }
    }

    private static void drawWandHints(Minecraft minecraft, GuiGraphicsExtractor graphics, ItemStack stack) {
        SortingWandSettings settings = SortingWandSettings.readFrom(stack);
        int screenWidth = minecraft.getWindow().getGuiScaledWidth();
        int screenHeight = minecraft.getWindow().getGuiScaledHeight();
        int y = screenHeight - 106;

        Component useKey = minecraft.options.keyUse.getTranslatedKeyMessage();
        Component menuKey = ClientKeyMappings.OPEN_SETTINGS.getTranslatedKeyMessage();
        Component quickKey = ClientKeyMappings.QUICK_SORT.getTranslatedKeyMessage();

        Component line1 = Component.translatable(
                "hud.simplesorter.wand_hint.line1",
                useKey,
                useKey,
                menuKey,
                quickKey
        );
        Component line2 = Component.translatable(
                "hud.simplesorter.wand_hint.line2",
                Component.translatable(settings.mode().translationKey()),
                settings.radius()
        );

        int width1 = minecraft.font.width(line1);
        int width2 = minecraft.font.width(line2);
        int boxWidth = Math.max(width1, width2) + 18;
        int x = (screenWidth - boxWidth) / 2;

        graphics.fill(x, y - 4, x + boxWidth, y + 20, HUD_BG);
        graphics.centeredText(minecraft.font, line1, screenWidth / 2, y, HUD_TEXT);
        graphics.centeredText(minecraft.font, line2, screenWidth / 2, y + 10, HUD_MUTED);
    }

    private static HeldWand getHeldWandWithHand(Player player) {
        if (isWand(player.getMainHandItem())) {
            return new HeldWand(player.getMainHandItem(), InteractionHand.MAIN_HAND);
        }
        if (isWand(player.getOffhandItem())) {
            return new HeldWand(player.getOffhandItem(), InteractionHand.OFF_HAND);
        }
        return HeldWand.EMPTY;
    }

    private static boolean isWand(ItemStack stack) {
        return !stack.isEmpty() && stack.getItem() == ModItems.SORTING_WAND.get();
    }

    private static void showSortingRadius(Minecraft minecraft, Player player, int configuredRadius) {
        double centerX = player.getX();
        double centerY = player.getY() + 0.06D;
        double centerZ = player.getZ();
        double radius = configuredRadius;
        int particles = Math.max(32, configuredRadius * 6);

        for (int i = 0; i < particles; i++) {
            double angle = (Math.PI * 2.0D * i) / particles;
            double x = centerX + Math.cos(angle) * radius;
            double z = centerZ + Math.sin(angle) * radius;
            addRadiusParticle(minecraft, x, centerY, z);
        }

        addRadiusParticle(minecraft, centerX + radius, centerY + 0.7D, centerZ);
        addRadiusParticle(minecraft, centerX - radius, centerY + 0.7D, centerZ);
        addRadiusParticle(minecraft, centerX, centerY + 0.7D, centerZ + radius);
        addRadiusParticle(minecraft, centerX, centerY + 0.7D, centerZ - radius);
    }

    private static void addRadiusParticle(Minecraft minecraft, double x, double y, double z) {
        minecraft.level.addParticle(ParticleTypes.END_ROD, x, y, z, 0.0D, 0.01D, 0.0D);
    }

    private record HeldWand(ItemStack stack, InteractionHand hand) {
        private static final HeldWand EMPTY = new HeldWand(ItemStack.EMPTY, InteractionHand.MAIN_HAND);
    }
}

package com.kirill.simplesorter;

import com.kirill.simplesorter.network.ModNetworking;
import com.kirill.simplesorter.registry.ModCreativeTabs;
import com.kirill.simplesorter.registry.ModItems;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.fml.common.Mod;

@Mod(SimpleSorterMod.MOD_ID)
public class SimpleSorterMod {
    public static final String MOD_ID = "simplesorter";

    public SimpleSorterMod(IEventBus modEventBus) {
        ModItems.register(modEventBus);
        ModCreativeTabs.register(modEventBus);
        modEventBus.addListener(ModNetworking::register);
    }
}

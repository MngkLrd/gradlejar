package com.kirill.simplesorter.network;
import net.fabricmc.fabric.api.networking.v1.PayloadTypeRegistry;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
public final class ModNetworking {
 private ModNetworking(){}
 public static void register(){
  PayloadTypeRegistry.playC2S().register(WandSettingsPayload.TYPE,WandSettingsPayload.STREAM_CODEC);
  PayloadTypeRegistry.playC2S().register(WandActionPayload.TYPE,WandActionPayload.STREAM_CODEC);
  ServerPlayNetworking.registerGlobalReceiver(WandSettingsPayload.TYPE,(payload,context)->WandSettingsPayload.handle(payload,context));
  ServerPlayNetworking.registerGlobalReceiver(WandActionPayload.TYPE,(payload,context)->WandActionPayload.handle(payload,context));
 }
}

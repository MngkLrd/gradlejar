package com.kirill.simplesorter.registry;
import com.kirill.simplesorter.item.SortingWandItem;
import net.fabricmc.fabric.api.itemgroup.v1.ItemGroupEvents;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.item.CreativeModeTabs;
import net.minecraft.world.item.Item;
import net.minecraft.core.Registry;
public final class ModItems {
 private ModItems(){}
 public static final Item SORTING_WAND = Registry.register(BuiltInRegistries.ITEM,
 ResourceLocation.fromNamespaceAndPath("simplesorter","sorting_wand"),
 new SortingWandItem(new Item.Properties().stacksTo(1).durability(128)));
 public static void init() { ItemGroupEvents.modifyEntriesEvent(CreativeModeTabs.TOOLS_AND_UTILITIES).register(entries -> entries.accept(SORTING_WAND)); }
}

package com.kirill.simplesorter.network;

import com.kirill.simplesorter.SimpleSorterMod;
import com.kirill.simplesorter.registry.ModItems;
import com.kirill.simplesorter.settings.SortingMode;
import com.kirill.simplesorter.settings.SortingWandSettings;
import com.kirill.simplesorter.sorting.SortCategoryRegistry;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.chat.Component;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;

public record WandSettingsPayload(
        int handIndex,
        int modeIndex,
        int radius,
        boolean showRadius,
        boolean showContainerHighlights,
        boolean showTransferParticles,
        boolean reloadRules
) implements CustomPacketPayload {
    public static final Type<WandSettingsPayload> TYPE = new Type<>(ResourceLocation.fromNamespaceAndPath(SimpleSorterMod.MOD_ID, "wand_settings"));

    public static final StreamCodec<RegistryFriendlyByteBuf, WandSettingsPayload> STREAM_CODEC = new StreamCodec<>() {
        @Override
        public WandSettingsPayload decode(RegistryFriendlyByteBuf buffer) {
            return new WandSettingsPayload(
                    buffer.readVarInt(),
                    buffer.readVarInt(),
                    buffer.readVarInt(),
                    buffer.readBoolean(),
                    buffer.readBoolean(),
                    buffer.readBoolean(),
                    buffer.readBoolean()
            );
        }

        @Override
        public void encode(RegistryFriendlyByteBuf buffer, WandSettingsPayload payload) {
            buffer.writeVarInt(payload.handIndex());
            buffer.writeVarInt(payload.modeIndex());
            buffer.writeVarInt(payload.radius());
            buffer.writeBoolean(payload.showRadius());
            buffer.writeBoolean(payload.showContainerHighlights());
            buffer.writeBoolean(payload.showTransferParticles());
            buffer.writeBoolean(payload.reloadRules());
        }
    };

    public static WandSettingsPayload save(InteractionHand hand, SortingWandSettings settings, boolean reloadRules) {
        SortingWandSettings safe = settings.sanitized();
        return new WandSettingsPayload(
                hand == InteractionHand.OFF_HAND ? 1 : 0,
                safe.mode().index(),
                safe.radius(),
                safe.showRadius(),
                safe.showContainerHighlights(),
                safe.showTransferParticles(),
                reloadRules
        );
    }

    @Override
    public Type<? extends CustomPacketPayload> type() {
        return TYPE;
    }

    public static void handle(WandSettingsPayload payload, ServerPlayNetworking.Context context) {
        context.server().execute(() -> {
            Player player = context.player();
            ItemStack stack = payload.handIndex() == 1 ? player.getOffhandItem() : player.getMainHandItem();
            if (stack.isEmpty() || stack.getItem() != ModItems.SORTING_WAND) {
                return;
            }

            SortingWandSettings settings = new SortingWandSettings(
                    SortingMode.byIndex(payload.modeIndex()),
                    payload.radius(),
                    payload.showRadius(),
                    payload.showContainerHighlights(),
                    payload.showTransferParticles()
            ).sanitized();
            settings.writeTo(stack);

            if (!payload.reloadRules()) {
                return;
            }

            if (!player.hasPermissions(2)) {
                player.displayClientMessage(Component.translatable("message.simplesorter.reload_denied"), true);
                return;
            }

            SortCategoryRegistry.reload();
            player.displayClientMessage(Component.translatable("message.simplesorter.rules_reloaded"), true);
        });
    }
}

# Simple Sorter 0.7.2 - NeoForge 1.21.1

Simple Sorter adds a limited-use Sorting Wand for cleaning nearby chests, barrels, shulkers, and supported modded item handlers in a real radius around the player.

## Main controls

- Right Click: use the selected sorting mode.
- Shift + Right Click: open the per-wand mini GUI.
- Settings are stored on the wand itself, so different wands can use different modes and radius values.

## Sorting modes

### Match Existing
Safer default mode. Moves items only into nearby containers that already contain the exact same item. This avoids the old problem where empty or mixed chests could become weird targets.

### Smart Categories
The older rule-driven mode. It uses category rules, tags, ids, class hints, and empty chests as category targets. Stronger, but less predictable than Match Existing.

### Compact Stacks
Only merges partial stacks. It does not place items into empty slots. Good when the storage is already arranged and only needs cleanup.

### Player Deposit
Moves matching items from the player's main inventory into nearby containers that already contain the same item. It skips Sorting Wands.

## Mini GUI

The 0.7.2 GUI is a proper settings panel rather than a debug list. It includes:

- sorting mode selector;
- radius selector with - / + controls;
- radius scale preview;
- visual toggles;
- Save, Reload Rules, and Cancel buttons;
- mode description card.

## Visuals

- Radius ring while holding the wand.
- Highlight particles on changed containers.
- Item-flight particle traces for selected moves.

All visual effects can be disabled per wand.

## Build

Required:

- Java 21
- Minecraft 1.21.1
- NeoForge 21.1.x
- Gradle 8.x

Build command:

```bat
gradle build
```

Expected jar:

```text
build/libs/simplesorter-0.7.2-neoforge.jar
```

## Testing checklist

1. Build the project with Java 21.
2. Launch Minecraft 1.21.1 with NeoForge.
3. Put the Sorting Wand in hand.
4. Shift + Right Click to open the mini GUI.
5. Switch between all four modes.
6. Save settings and check the tooltip.
7. Test Match Existing on mixed chests.
8. Test Compact Stacks with several partial stacks.
9. Test Player Deposit after mining or farming.
10. Test Smart Categories separately because it is intentionally more aggressive.

## Known limitations

- Smart Categories can still move items aggressively because it tries to assign category roles to containers.
- Match Existing is the recommended normal survival mode.
- Player Deposit works with the player's main inventory and does not intentionally move equipped armor/offhand items.
- Large storages may create many possible moves, so visual traces are capped.


## 0.7.2 polish update

- Reworked the mini GUI background so it no longer uses the ugly vanilla blurred text layer behind the panel.
- Replaced internal mode ids in actionbar messages with translated mode names.
- Added unobtrusive HUD hints above the hotbar while holding the Sorting Wand.
- Added Minecraft Controls keybinds: Open Sorting Wand Menu and Quick Sort Nearby Containers.
- Added local chest cleanup after sorting: partial stacks are merged and scattered stacks are packed into earlier slots when the container accepts it.
- Added Defaults button in the wand GUI.

## 0.7.2 fixes

- HUD hint moved higher so it does not overlap vanilla actionbar messages.
- Wand settings screen now uses a fully solid background and suppresses the vanilla blurred ghost layer.
- The confusing `Flights` visual toggle was renamed to `Transfer FX` in English and `Анимация` in Russian.
- Added direct GUI actions: `Run Selected` and `Deposit Now`. `Deposit Now` runs Player Deposit immediately from the GUI without requiring a separate right-click after saving.
- English and Russian language files were checked for matching translation keys.


## 0.8.0 rework (Minecraft 1.21.1)

- Chunk block-entity scan replaces exhaustive block-volume traversal (nearest 160 candidates).
- Inventory transfer has emergency world-drop recovery for a misbehaving modded handler; items are not silently discarded.
- Player Deposit no longer reorganizes every nearby chest.
- Smart Categories only targets established nonempty storage categories; empty containers remain untouched.
- Sorting results and saves no longer spam the action bar.
- Wand durability: 128 uses and only consumed after an actual change.
- Slimmer local radius wireframe and lower particle budgets.
- Recipe category fixed for Minecraft 1.21.1.

### Known limitations

- Storage access is mediated through NeoForge inventory capabilities, but external claim/protection mods may require an explicit compatibility bridge.
- The scanner selects at most 160 nearby block entities to bound main-thread cost.
- JEI is optional.

Simple Sorter Fabric 26.2, Java 25. Initial port; tested via GitHub CI.

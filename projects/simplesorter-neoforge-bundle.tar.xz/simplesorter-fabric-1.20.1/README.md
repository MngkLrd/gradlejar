Simple Sorter Fabric 1.20.1. Java 17. Build: gradle --no-daemon build. Full GUI and quick-sort feature port (compile verification required).

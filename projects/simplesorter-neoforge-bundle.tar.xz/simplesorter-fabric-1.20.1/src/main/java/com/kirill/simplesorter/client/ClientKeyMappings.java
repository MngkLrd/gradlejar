package com.kirill.simplesorter.client;
import com.mojang.blaze3d.platform.InputConstants;
import net.minecraft.client.KeyMapping;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import org.lwjgl.glfw.GLFW;
public final class ClientKeyMappings {
 private ClientKeyMappings(){}
 public static final String CATEGORY="key.categories.simplesorter";
 public static final KeyMapping OPEN_SETTINGS=new KeyMapping("key.simplesorter.open_settings",InputConstants.Type.KEYSYM,GLFW.GLFW_KEY_G,CATEGORY);
 public static final KeyMapping QUICK_SORT=new KeyMapping("key.simplesorter.quick_sort",InputConstants.Type.KEYSYM,GLFW.GLFW_KEY_H,CATEGORY);
 public static void init(){KeyBindingHelper.registerKeyBinding(OPEN_SETTINGS);KeyBindingHelper.registerKeyBinding(QUICK_SORT);}
}

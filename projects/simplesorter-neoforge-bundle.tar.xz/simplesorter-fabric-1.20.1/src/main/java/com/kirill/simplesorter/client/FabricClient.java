package com.kirill.simplesorter.client;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
public class FabricClient implements ClientModInitializer {
 @Override public void onInitializeClient(){
  ClientKeyMappings.init();
  ClientTickEvents.END_CLIENT_TICK.register(ClientEventHandler::onClientTick);
  HudRenderCallback.EVENT.register((graphics, delta) -> ClientEventHandler.onRenderGui(graphics));
 }
}

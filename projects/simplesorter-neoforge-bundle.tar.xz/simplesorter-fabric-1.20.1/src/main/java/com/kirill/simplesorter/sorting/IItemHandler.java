package com.kirill.simplesorter.sorting;
import net.minecraft.world.item.ItemStack;
public interface IItemHandler {
 int getSlots(); ItemStack getStackInSlot(int slot);
 ItemStack insertItem(int slot, ItemStack stack, boolean simulate);
 ItemStack extractItem(int slot, int amount, boolean simulate);
}

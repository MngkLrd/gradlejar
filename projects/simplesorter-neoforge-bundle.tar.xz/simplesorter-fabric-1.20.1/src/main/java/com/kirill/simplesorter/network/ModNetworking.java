package com.kirill.simplesorter.network;
import com.kirill.simplesorter.SimpleSorterMod;
import net.minecraft.resources.ResourceLocation;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
public final class ModNetworking {
 public static final ResourceLocation SAVE=new ResourceLocation(SimpleSorterMod.MOD_ID,"wand_settings");
 public static final ResourceLocation ACTION=new ResourceLocation(SimpleSorterMod.MOD_ID,"wand_action");
 private ModNetworking(){}
 public static void register(){
  ServerPlayNetworking.registerGlobalReceiver(SAVE,(server,player,handler,buf,responseSender)->{
    WandSettingsPayload payload=WandSettingsPayload.read(buf);server.execute(()->payload.handle(player));
  });
  ServerPlayNetworking.registerGlobalReceiver(ACTION,(server,player,handler,buf,responseSender)->{
    WandActionPayload payload=WandActionPayload.read(buf);server.execute(()->payload.handle(player));
  });
 }
}

package com.kirill.simplesorter.network;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.fabricmc.fabric.api.networking.v1.PacketByteBufs;
public final class ClientNetwork{
 private ClientNetwork(){}
 public static void send(WandActionPayload p){var b=PacketByteBufs.create();p.write(b);ClientPlayNetworking.send(ModNetworking.ACTION,b);}
 public static void send(WandSettingsPayload p){var b=PacketByteBufs.create();p.write(b);ClientPlayNetworking.send(ModNetworking.SAVE,b);}
}

package com.kirill.simplesorter.registry;

import com.kirill.simplesorter.SimpleSorterMod;
import com.kirill.simplesorter.item.SortingWandItem;
import net.minecraft.world.item.Item;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.neoforge.registries.DeferredItem;
import net.neoforged.neoforge.registries.DeferredRegister;

public final class ModItems {
    private ModItems() {}

    public static final DeferredRegister.Items ITEMS = DeferredRegister.createItems(SimpleSorterMod.MOD_ID);

    public static final DeferredItem<Item> SORTING_WAND = ITEMS.register("sorting_wand",
            () -> new SortingWandItem(new Item.Properties().stacksTo(1).durability(128)));

    public static void register(IEventBus eventBus) {
        ITEMS.register(eventBus);
    }
}

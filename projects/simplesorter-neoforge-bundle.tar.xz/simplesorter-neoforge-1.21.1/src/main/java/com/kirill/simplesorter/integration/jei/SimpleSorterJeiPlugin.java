package com.kirill.simplesorter.integration.jei;

import com.kirill.simplesorter.SimpleSorterMod;
import com.kirill.simplesorter.registry.ModItems;
import mezz.jei.api.IModPlugin;
import mezz.jei.api.JeiPlugin;
import mezz.jei.api.registration.IRecipeRegistration;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.item.ItemStack;

@JeiPlugin
public final class SimpleSorterJeiPlugin implements IModPlugin {
    private static final ResourceLocation UID = ResourceLocation.fromNamespaceAndPath(SimpleSorterMod.MOD_ID, "jei_plugin");

    @Override
    public ResourceLocation getPluginUid() {
        return UID;
    }

    @Override
    public void registerRecipes(IRecipeRegistration registration) {
        registration.addItemStackInfo(
                new ItemStack(ModItems.SORTING_WAND.get()),
                Component.translatable("jei.simplesorter.sorting_wand.info.1"),
                Component.translatable("jei.simplesorter.sorting_wand.info.2"),
                Component.translatable("jei.simplesorter.sorting_wand.info.3"),
                Component.translatable("jei.simplesorter.sorting_wand.info.4")
        );
    }
}
